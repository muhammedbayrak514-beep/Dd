# GitHub Actions NDK düzeltmesi

Bu pakette `android/app/build.gradle` dosyası NDK `28.2.13676358` sürümüne sabitlenmiştir.

Son hata, Dart kodundan veya YAML sözdiziminden kaynaklanmıyordu. Android SDK Manager NDK indirme arşivini açarken `Error on ZipFile unknown archive` hatası vermişti. GitHub Actions iş akışına, arşiv önbelleğini ve yarım kalmış NDK klasörünü temizleyip NDK kurulumunu en fazla üç kez yeniden deneyen bir adım eklendi.

ÖNEMLİ: Depodaki `.github/workflows/android-apk.yml` dosyasını da bu paketteki `github_upload_kit/.github/workflows/android-apk.yml` ile güncelleyin. Yalnızca uygulama ZIP'ini değiştirmek, deponun kökündeki zaten mevcut workflow dosyasını otomatik olarak değiştirmez.

Bu değişiklikler logda görülen NDK arşiv hatasını hedefler; burada tam Android SDK/Flutter ortamı bulunmadığından APK'nın başarıyla üretildiği doğrulanmış değildir.
