import 'package:collection/collection.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/project_repository.dart';
import '../../domain/edit_history.dart';
import '../../domain/models/clip_model.dart';
import '../../domain/models/project_model.dart';
import '../../domain/timeline_ops.dart';
import 'preview_provider.dart';
import 'project_list_provider.dart';
import 'timeline_clock_provider.dart';

final editorProvider =
    AsyncNotifierProvider.family<EditorNotifier, ProjectModel, String>(
  EditorNotifier.new,
);

final historyUiProvider =
    StateProvider.family<HistoryUiState, String>((ref, projectId) {
  return const HistoryUiState();
});

class EditorNotifier extends FamilyAsyncNotifier<ProjectModel, String> {
  ProjectRepository get _repo => ref.read(projectRepositoryProvider);
  final EditHistory _history = EditHistory();
  bool _saving = false;
  /// Monotonic generation so a late-finishing save cannot overwrite a newer state.
  int _saveGeneration = 0;
  Future<void>? _saveChain;

  String get projectId => arg;

  @override
  Future<ProjectModel> build(String projectId) async {
    final project = await _repo.getProject(projectId);
    if (project == null) {
      throw Exception('Proje bulunamadı: $projectId');
    }
    _history.clear();
    _publishHistory();
    return project;
  }

  Future<void> load() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => build(projectId));
  }

  /// Serializes disk writes; always persists the *latest* state after the chain.
  Future<void> save() {
    final gen = ++_saveGeneration;
    final previous = _saveChain ?? Future.value();
    _saveChain = previous.then((_) => _saveAt(gen)).catchError((e, st) {
      // Keep chain alive after failure
    });
    return _saveChain!;
  }

  Future<void> _saveAt(int gen) async {
    // Wait until we are the latest requested generation's runner,
    // but still write the current in-memory state once per turn of the chain.
    if (gen < _saveGeneration) {
      // A newer save was requested; the chain will call us again via later link.
      return;
    }
    final current = state.value;
    if (current == null) return;
    // Guard against writing wrong project after notifier rebuild
    if (current.id != projectId) return;
    _saving = true;
    try {
      await _repo.saveProject(current);
      // If state advanced during await, schedule another save
      if (gen < _saveGeneration) {
        return;
      }
      // Re-check: if still same generation, refresh list once
      ref.read(projectListProvider.notifier).refresh();
    } finally {
      _saving = false;
      // If mutations happened while saving, ensure latest is flushed
      if (gen < _saveGeneration && state.value != null) {
        // chain continues via subsequent save() links
      }
    }
  }

  void _publishHistory() {
    ref.read(historyUiProvider(projectId).notifier).state =
        HistoryUiState.from(_history);
  }

  Future<void> _commit(ProjectModel next) async {
    final current = state.value;
    if (current != null) {
      _history.pushBeforeChange(current);
    }
    state = AsyncData(next);
    _publishHistory();
    await save();
  }

  Future<void> applyLive(ProjectModel next) async {
    state = AsyncData(next);
  }

  void beginContinuousEdit(String key) {
    final current = state.value;
    if (current == null) return;
    _history.beginCoalesce(current, key);
    _publishHistory();
  }

  Future<void> endContinuousEdit() async {
    _history.endCoalesce();
    _publishHistory();
    await save();
  }

  Future<void> undo() async {
    final current = state.value;
    if (current == null || !_history.canUndo) return;
    final prev = _history.undo(current);
    if (prev == null) return;
    state = AsyncData(prev);
    _publishHistory();
    await save();
    _clampPlayhead(prev);
    _fixSelection(prev);
  }

  Future<void> redo() async {
    final current = state.value;
    if (current == null || !_history.canRedo) return;
    final next = _history.redo(current);
    if (next == null) return;
    state = AsyncData(next);
    _publishHistory();
    await save();
    _clampPlayhead(next);
    _fixSelection(next);
  }

  void _fixSelection(ProjectModel project) {
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected != null && !project.clips.any((c) => c.id == selected)) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          project.clips.isNotEmpty ? project.clips.first.id : null;
    }
  }

  Future<void> addClips(List<ClipModel> clips) async {
    final current = state.value;
    if (current == null) return;
    var updated = current;
    for (final clip in clips) {
      updated = updated.addClip(clip);
    }
    await _commit(updated);
  }

  Future<void> updateClip(ClipModel clip, {bool continuous = false}) async {
    final current = state.value;
    if (current == null) return;
    final next = current.updateClip(clip);
    if (continuous) {
      await applyLive(next);
    } else {
      await _commit(next);
    }
  }

  Future<void> trimClip({
    required String clipId,
    required int trimStartMs,
    required int trimEndMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.trimClip(
      project: current,
      clipId: clipId,
      newTrimStartMs: trimStartMs,
      newTrimEndMs: trimEndMs,
    );
    if (continuous) {
      await applyLive(updated);
    } else {
      await _commit(updated);
      _clampPlayhead(updated);
      _reloadPreviewIfSelected(clipId);
    }
  }

  Future<bool> splitAtPlayhead(String clipId) async {
    final current = state.value;
    if (current == null) return false;
    final playhead = ref.read(timelineClockProvider(projectId)).positionMs;
    final result = TimelineOps.splitClip(
      project: current,
      clipId: clipId,
      projectTimeMs: playhead,
    );
    if (result == null) return false;
    await _commit(result);
    ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
    _clampPlayhead(result);
    return true;
  }

  Future<void> deleteClip(String clipId) async {
    final current = state.value;
    if (current == null) return;
    final updated = TimelineOps.deleteClip(project: current, clipId: clipId);
    await _commit(updated);
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected == clipId) {
      ref.read(selectedClipIdProvider(projectId).notifier).state =
          updated.clips.isNotEmpty ? updated.clips.first.id : null;
    }
    _clampPlayhead(updated);
  }

  Future<void> removeClip(String clipId) => deleteClip(clipId);

  Future<void> moveClipLeft(String clipId) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.moveClip(
      project: current,
      clipId: clipId,
      direction: -1,
    ));
  }

  Future<void> moveClipRight(String clipId) async {
    final current = state.value;
    if (current == null) return;
    await _commit(TimelineOps.moveClip(
      project: current,
      clipId: clipId,
      direction: 1,
    ));
  }

  Future<void> addTextClip({
    required String content,
    int durationMs = 3000,
    int? timelineStartMs,
  }) async {
    final current = state.value;
    if (current == null) return;
    final start = timelineStartMs ??
        ref.read(timelineClockProvider(projectId)).positionMs;
    final clip = ClipModel.text(
      content: content,
      durationMs: durationMs,
      timelineStartMs: start,
    );
    await _commit(current.addClip(clip));
    ref.read(selectedClipIdProvider(projectId).notifier).state = clip.id;
  }

  Future<void> addAudioClip(ClipModel audioClip) async {
    final current = state.value;
    if (current == null) return;
    await _commit(current.addClip(audioClip));
    ref.read(selectedClipIdProvider(projectId).notifier).state = audioClip.id;
  }

  Future<void> updateTextClip({
    required String clipId,
    String? textContent,
    double? fontSize,
    int? textColorArgb,
    int? textAlign,
    double? posX,
    double? posY,
    int? durationMs,
    bool continuous = false,
  }) async {
    final current = state.value;
    if (current == null) return;
    final clip = current.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null || clip.type != ClipType.text) return;
    var updated = clip;
    if (textContent != null) {
      final name = textContent.length > 24
          ? '${textContent.substring(0, 24)}…'
          : textContent;
      updated = updated.copyWith(
        textContent: textContent,
        displayName: name,
      );
    }
    if (fontSize != null) updated = updated.copyWith(fontSize: fontSize);
    if (textColorArgb != null) {
      updated = updated.copyWith(textColorArgb: textColorArgb);
    }
    if (textAlign != null) updated = updated.copyWith(textAlign: textAlign);
    if (posX != null) updated = updated.copyWith(posX: posX);
    if (posY != null) updated = updated.copyWith(posY: posY);
    if (durationMs != null && durationMs >= 100) {
      updated = updated.copyWith(
        sourceDurationMs: durationMs,
        trimEndMs: durationMs,
        trimStartMs: 0,
      );
    }
    final next = current.updateClip(updated);
    if (continuous) {
      await applyLive(next);
    } else {
      await _commit(next);
    }
  }

  void _clampPlayhead(ProjectModel project) {
    final max = project.durationMs;
    final clock = ref.read(timelineClockProvider(projectId));
    if (clock.positionMs > max) {
      ref.read(timelineClockProvider(projectId).notifier).setPosition(max);
    }
  }

  void _reloadPreviewIfSelected(String clipId) {
    final selected = ref.read(selectedClipIdProvider(projectId));
    if (selected == clipId) {
      ref.read(selectedClipIdProvider(projectId).notifier).state = null;
      Future.microtask(() {
        ref.read(selectedClipIdProvider(projectId).notifier).state = clipId;
      });
    }
  }
}
