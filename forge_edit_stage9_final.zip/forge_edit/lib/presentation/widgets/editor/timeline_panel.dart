import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../../domain/models/clip_model.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';

/// Timeline with time ruler, positioned clips, and shared playhead.
///
/// Stage 4:
/// - Clips laid out by timelineStartMs * pixelsPerMs (model-accurate)
/// - Time ruler with second/major ticks
/// - Draggable playhead (updates TimelineClock)
/// - Horizontal scroll for long timelines
/// - Tap clip → select + load preview (unchanged)
///
/// NOT in Stage 4:
/// - Continuous multi-clip playback
/// - Bidirectional full sync while playing across clips
class TimelinePanel extends ConsumerStatefulWidget {
  final String projectId;

  const TimelinePanel({super.key, required this.projectId});

  @override
  ConsumerState<TimelinePanel> createState() => _TimelinePanelState();
}

class _TimelinePanelState extends ConsumerState<TimelinePanel> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editorState = ref.watch(editorProvider(widget.projectId));
    final clock = ref.watch(timelineClockProvider(widget.projectId));
    final selectedId = ref.watch(selectedClipIdProvider(widget.projectId));
    final project = editorState.value;
    final clips = project?.clips ?? [];
    final durationMs = project?.durationMs ?? 0;

    // Extra padding so playhead can sit past last clip
    final contentWidth = _contentWidth(durationMs, clock.pixelsPerMs);

    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _TimelineHeader(
            projectId: widget.projectId,
            durationMs: durationMs,
            positionMs: clock.positionMs,
          ),
          Expanded(
            child: clips.isEmpty
                ? const Center(
                    child: Text(
                      'Klip eklemek için sağ paneli kullan',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                  )
                : LayoutBuilder(
                    builder: (context, constraints) {
                      return SingleChildScrollView(
                        controller: _scrollController,
                        scrollDirection: Axis.horizontal,
                        child: SizedBox(
                          width: contentWidth.clamp(
                            constraints.maxWidth,
                            double.infinity,
                          ),
                          height: constraints.maxHeight,
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              // Ruler
                              Positioned(
                                top: 0,
                                left: 0,
                                right: 0,
                                height: 28,
                                child: _TimeRuler(
                                  durationMs: durationMs,
                                  pixelsPerMs: clock.pixelsPerMs,
                                  width: contentWidth,
                                ),
                              ),
                              // Clip track
                              Positioned(
                                top: 28,
                                left: 0,
                                right: 0,
                                bottom: 0,
                                child: _ClipTrack(
                                  clips: clips,
                                  selectedId: selectedId,
                                  pixelsPerMs: clock.pixelsPerMs,
                                  onSelect: (id) {
                                    ref
                                        .read(selectedClipIdProvider(
                                                widget.projectId)
                                            .notifier)
                                        .state = id;
                                  },
                                ),
                              ),
                              // Playhead
                              Positioned(
                                top: 0,
                                bottom: 0,
                                left: clock.positionMs * clock.pixelsPerMs,
                                child: _Playhead(
                                  onDrag: (dx) {
                                    final newMs = (clock.positionMs +
                                            (dx / clock.pixelsPerMs))
                                        .round()
                                        .clamp(0, durationMs > 0 ? durationMs : 0);
                                    ref
                                        .read(timelineClockProvider(
                                                widget.projectId)
                                            .notifier)
                                        .setPosition(newMs);
                                    _seekPreviewToProjectTime(
                                      ref,
                                      widget.projectId,
                                      project,
                                      newMs,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  double _contentWidth(int durationMs, double pixelsPerMs) {
    final base = durationMs * pixelsPerMs;
    // Minimum comfortable width + trailing space for playhead
    return (base + 120).clamp(400.0, 200000.0);
  }

  /// If playhead falls inside a video clip, seek that clip's controller.
  /// Does not auto-switch selection (avoids surprising jumps). Only seeks
  /// when the currently selected clip contains [projectMs].
  void _seekPreviewToProjectTime(
    WidgetRef ref,
    String projectId,
    ProjectModel? project,
    int projectMs,
  ) {
    if (project == null) return;
    final selectedId = ref.read(selectedClipIdProvider(projectId));
    if (selectedId == null) return;
    final clip = project.clips.where((c) => c.id == selectedId).firstOrNull;
    if (clip == null || clip.type != ClipType.video) return;

    if (projectMs < clip.timelineStartMs || projectMs >= clip.timelineEndMs) {
      return; // outside selected clip – no seek
    }

    final localMs = projectMs - clip.timelineStartMs + clip.trimStartMs;
    ref
        .read(previewProvider(projectId).notifier)
        .seek(Duration(milliseconds: localMs.clamp(0, clip.trimEndMs)));
  }
}

class _TimelineHeader extends ConsumerWidget {
  final String projectId;
  final int durationMs;
  final int positionMs;

  const _TimelineHeader({
    required this.projectId,
    required this.durationMs,
    required this.positionMs,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          Text(
            'Zaman Çizelgesi',
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(width: 16),
          Text(
            '${TimeFormatter.formatMs(positionMs)} / ${TimeFormatter.formatMs(durationMs)}',
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 12,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.zoom_out, size: 20),
            tooltip: 'Uzaklaştır',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).zoomOut(),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            icon: const Icon(Icons.zoom_in, size: 20),
            tooltip: 'Yakınlaştır',
            onPressed: () =>
                ref.read(timelineClockProvider(projectId).notifier).zoomIn(),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}

class _TimeRuler extends StatelessWidget {
  final int durationMs;
  final double pixelsPerMs;
  final double width;

  const _TimeRuler({
    required this.durationMs,
    required this.pixelsPerMs,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(width, 28),
      painter: _RulerPainter(
        durationMs: durationMs,
        pixelsPerMs: pixelsPerMs,
      ),
    );
  }
}

class _RulerPainter extends CustomPainter {
  final int durationMs;
  final double pixelsPerMs;

  _RulerPainter({required this.durationMs, required this.pixelsPerMs});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.border
      ..strokeWidth = 1;

    final labelStyle = TextStyle(
      color: AppTheme.textSecondary.withValues(alpha: 0.9),
      fontSize: 10,
    );

    // Major tick every 1s or 5s depending on zoom
    final pxPerSec = pixelsPerMs * 1000;
    final majorEverySec = pxPerSec >= 60 ? 1 : (pxPerSec >= 20 ? 5 : 10);
    final majorMs = majorEverySec * 1000;
    final minorMs = majorEverySec <= 1 ? 200 : 1000;

    final end = durationMs + 5000; // draw a bit past end
    for (var t = 0; t <= end; t += minorMs) {
      final x = t * pixelsPerMs;
      if (x > size.width) break;
      final isMajor = t % majorMs == 0;
      final h = isMajor ? 14.0 : 6.0;
      canvas.drawLine(
        Offset(x, size.height - h),
        Offset(x, size.height),
        paint,
      );
      if (isMajor) {
        final tp = TextPainter(
          text: TextSpan(
            text: TimeFormatter.formatMs(t),
            style: labelStyle,
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(x + 2, 2));
      }
    }

    // Baseline
    canvas.drawLine(
      Offset(0, size.height - 0.5),
      Offset(size.width, size.height - 0.5),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _RulerPainter old) =>
      old.durationMs != durationMs || old.pixelsPerMs != pixelsPerMs;
}

class _ClipTrack extends StatelessWidget {
  final List<ClipModel> clips;
  final String? selectedId;
  final double pixelsPerMs;
  final void Function(String id) onSelect;

  const _ClipTrack({
    required this.clips,
    required this.selectedId,
    required this.pixelsPerMs,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        for (final clip in clips)
          Positioned(
            left: clip.timelineStartMs * pixelsPerMs,
            width: (clip.durationMs * pixelsPerMs).clamp(24.0, 100000.0),
            top: 8,
            bottom: 8,
            child: _ClipBlock(
              clip: clip,
              selected: clip.id == selectedId,
              onTap: () => onSelect(clip.id),
            ),
          ),
      ],
    );
  }
}

class _ClipBlock extends StatelessWidget {
  final ClipModel clip;
  final bool selected;
  final VoidCallback onTap;

  const _ClipBlock({
    required this.clip,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Color baseColor;
    switch (clip.type) {
      case ClipType.video:
      case ClipType.image:
        baseColor = AppTheme.primary;
        break;
      case ClipType.audio:
        baseColor = AppTheme.accent;
        break;
      case ClipType.text:
        baseColor = AppTheme.warning;
        break;
    }

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: baseColor.withValues(alpha: selected ? 0.45 : 0.28),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: selected ? baseColor : baseColor.withValues(alpha: 0.55),
            width: selected ? 2 : 1,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              clip.displayName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
            ),
            if (clip.filterId != 'none')
              Text(
                clip.filterId,
                maxLines: 1,
                style: const TextStyle(fontSize: 9, color: AppTheme.accent),
              ),
            if (clip.transitionId != 'none')
              Text(
                '→ ${clip.transitionId}',
                maxLines: 1,
                style: const TextStyle(fontSize: 9, color: AppTheme.warning),
              ),
          ],
        ),
      ),
    );
  }
}

class _Playhead extends StatelessWidget {
  final void Function(double dx) onDrag;

  const _Playhead({required this.onDrag});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onHorizontalDragUpdate: (d) => onDrag(d.delta.dx),
      child: SizedBox(
        width: 20,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            // Vertical line
            Positioned(
              top: 0,
              bottom: 0,
              child: Container(
                width: 2,
                color: AppTheme.playhead,
              ),
            ),
            // Head handle
            Positioned(
              top: 0,
              child: CustomPaint(
                size: const Size(12, 10),
                painter: _PlayheadHeadPainter(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayheadHeadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = AppTheme.playhead);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
