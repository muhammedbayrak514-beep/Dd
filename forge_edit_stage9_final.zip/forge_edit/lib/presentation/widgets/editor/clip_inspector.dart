import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/time_formatter.dart';
import '../../../domain/models/clip_model.dart';
import '../../providers/editor_provider.dart';
import '../../providers/preview_provider.dart';
import '../../providers/timeline_clock_provider.dart';

/// Bottom-of-tools / overlay controls for the selected clip.
/// Stage 5: trim handles (start/end sliders), split, delete, reorder.
class ClipInspector extends ConsumerWidget {
  final String projectId;

  const ClipInspector({super.key, required this.projectId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedId = ref.watch(selectedClipIdProvider(projectId));
    final project = ref.watch(editorProvider(projectId)).value;
    if (selectedId == null || project == null) {
      return const SizedBox.shrink();
    }
    final clip = project.clips.where((c) => c.id == selectedId).firstOrNull;
    if (clip == null) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: const BoxDecoration(
        color: AppTheme.surfaceElevated,
        border: Border(top: BorderSide(color: AppTheme.border)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  clip.displayName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ),
              Text(
                TimeFormatter.formatMs(clip.durationMs),
                style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Trim range (source time)
          _TrimSliders(projectId: projectId, clip: clip),
          const SizedBox(height: 8),
          // Volume for audio
          if (clip.type == ClipType.audio) ...[
            Text(
              'Ses: ${(clip.volume * 100).round()}%',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              value: clip.volume.clamp(0.0, 1.0),
              onChangeStart: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .beginContinuousEdit('vol_${clip.id}');
              },
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateClip(
                      clip.copyWith(volume: v),
                      continuous: true,
                    );
              },
              onChangeEnd: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .endContinuousEdit();
              },
            ),
          ],
          // Text content edit
          if (clip.type == ClipType.text) ...[
            TextField(
              controller: TextEditingController(text: clip.textContent),
              maxLines: 2,
              style: const TextStyle(fontSize: 13),
              decoration: const InputDecoration(
                isDense: true,
                labelText: 'Metin',
              ),
              onSubmitted: (v) {
                if (v.trim().isEmpty) return;
                ref.read(editorProvider(projectId).notifier).updateTextClip(
                      clipId: clip.id,
                      textContent: v.trim(),
                    );
              },
            ),
            const SizedBox(height: 4),
            Text(
              'Boyut: ${clip.fontSize.round()}',
              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
            ),
            Slider(
              min: 12,
              max: 96,
              value: clip.fontSize.clamp(12, 96),
              onChangeStart: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .beginContinuousEdit('font_${clip.id}');
              },
              onChanged: (v) {
                ref.read(editorProvider(projectId).notifier).updateTextClip(
                      clipId: clip.id,
                      fontSize: v,
                      continuous: true,
                    );
              },
              onChangeEnd: (_) {
                ref
                    .read(editorProvider(projectId).notifier)
                    .endContinuousEdit();
              },
            ),
          ],
          // Action buttons
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _ActionChip(
                icon: Icons.content_cut,
                label: 'Böl',
                onPressed: () async {
                  final ok = await ref
                      .read(editorProvider(projectId).notifier)
                      .splitAtPlayhead(clip.id);
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        ok
                            ? 'Klip playhead konumunda bölündü'
                            : 'Bölme geçersiz (playhead klip içinde ve kenarlardan uzak olmalı)',
                      ),
                      backgroundColor: ok ? null : AppTheme.danger,
                    ),
                  );
                },
              ),
              _ActionChip(
                icon: Icons.arrow_back,
                label: 'Sola',
                onPressed: () => ref
                    .read(editorProvider(projectId).notifier)
                    .moveClipLeft(clip.id),
              ),
              _ActionChip(
                icon: Icons.arrow_forward,
                label: 'Sağa',
                onPressed: () => ref
                    .read(editorProvider(projectId).notifier)
                    .moveClipRight(clip.id),
              ),
              _ActionChip(
                icon: Icons.delete_outline,
                label: 'Sil',
                danger: true,
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Klibi sil'),
                      content: Text('"${clip.displayName}" silinsin mi?'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, false),
                          child: const Text('İptal'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Sil'),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    await ref
                        .read(editorProvider(projectId).notifier)
                        .deleteClip(clip.id);
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Böl: playhead seçili klibin içinde olmalı. '
            'Sıralama yalnızca ana video kanalında.',
            style: TextStyle(
              color: AppTheme.textSecondary.withValues(alpha: 0.8),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrimSliders extends ConsumerWidget {
  final String projectId;
  final ClipModel clip;

  const _TrimSliders({required this.projectId, required this.clip});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final max = clip.sourceDurationMs.toDouble().clamp(1, double.infinity);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Kesim: ${TimeFormatter.formatMs(clip.trimStartMs)} → ${TimeFormatter.formatMs(clip.trimEndMs)}',
          style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
        ),
        Row(
          children: [
            const SizedBox(
              width: 40,
              child: Text('Baş', style: TextStyle(fontSize: 11)),
            ),
            Expanded(
              child: Slider(
                min: 0,
                max: max,
                value: clip.trimStartMs.toDouble().clamp(0, max),
                onChangeStart: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .beginContinuousEdit('trim_start_${clip.id}');
                },
                onChanged: (v) {
                  final start = v.round();
                  final end = clip.trimEndMs;
                  if (end - start < 100) return;
                  ref.read(editorProvider(projectId).notifier).trimClip(
                        clipId: clip.id,
                        trimStartMs: start,
                        trimEndMs: end,
                        continuous: true,
                      );
                },
                onChangeEnd: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .endContinuousEdit();
                },
              ),
            ),
          ],
        ),
        Row(
          children: [
            const SizedBox(
              width: 40,
              child: Text('Bit', style: TextStyle(fontSize: 11)),
            ),
            Expanded(
              child: Slider(
                min: 0,
                max: max,
                value: clip.trimEndMs.toDouble().clamp(0, max),
                onChangeStart: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .beginContinuousEdit('trim_end_${clip.id}');
                },
                onChanged: (v) {
                  final end = v.round();
                  final start = clip.trimStartMs;
                  if (end - start < 100) return;
                  ref.read(editorProvider(projectId).notifier).trimClip(
                        clipId: clip.id,
                        trimStartMs: start,
                        trimEndMs: end,
                        continuous: true,
                      );
                },
                onChangeEnd: (_) {
                  ref
                      .read(editorProvider(projectId).notifier)
                      .endContinuousEdit();
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _ActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  final bool danger;

  const _ActionChip({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      avatar: Icon(icon, size: 16, color: danger ? AppTheme.danger : null),
      label: Text(label),
      onPressed: onPressed,
      backgroundColor: AppTheme.surface,
      side: BorderSide(
        color: danger ? AppTheme.danger.withValues(alpha: 0.5) : AppTheme.border,
      ),
    );
  }
}

extension _FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull {
    final it = iterator;
    if (it.moveNext()) return it.current;
    return null;
  }
}
