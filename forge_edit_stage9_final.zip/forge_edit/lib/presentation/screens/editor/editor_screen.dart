import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/editor_provider.dart';
import '../../widgets/editor/preview_panel.dart';
import '../../widgets/editor/timeline_panel.dart';
import '../../widgets/editor/tool_panel.dart';
import '../../widgets/editor/editor_top_bar.dart';
import '../../widgets/editor/clip_inspector.dart';

/// Main editor screen – landscape-first layout for tablets.
///
/// Layout:
/// ┌──────────────────────────────────────────────┐
/// │ Top bar (back, name, undo/redo, export)      │
/// ├────────────────────────────┬─────────────────┤
/// │                            │                 │
/// │      Preview Panel         │   Tool Panel    │
/// │                            │                 │
/// ├────────────────────────────┴─────────────────┤
/// │              Timeline Panel                  │
/// └──────────────────────────────────────────────┘
class EditorScreen extends ConsumerStatefulWidget {
  final String projectId;

  const EditorScreen({super.key, required this.projectId});

  @override
  ConsumerState<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends ConsumerState<EditorScreen> {
  @override
  void initState() {
    super.initState();
    // Load project after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(editorProvider(widget.projectId).notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final editorState = ref.watch(editorProvider(widget.projectId));

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: editorState.when(
          loading: () => const Center(
            child: CircularProgressIndicator(color: AppTheme.primary),
          ),
          error: (e, _) => _ErrorView(
            message: e.toString(),
            onBack: () => Navigator.of(context).pop(),
          ),
          data: (project) => _EditorBody(
            project: project,
            projectId: widget.projectId,
          ),
        ),
      ),
    );
  }
}

class _EditorBody extends StatelessWidget {
  final ProjectModel project;
  final String projectId;

  const _EditorBody({required this.project, required this.projectId});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Top controls
        EditorTopBar(project: project, projectId: projectId),

        // Middle: Preview + Tools
        Expanded(
          flex: 3,
          child: Row(
            children: [
              // Preview takes most of the width
              Expanded(
                flex: 3,
                child: PreviewPanel(projectId: projectId),
              ),
              // Tool panel on the right
              SizedBox(
                width: 280,
                child: ToolPanel(projectId: projectId),
              ),
            ],
          ),
        ),

        // Selected clip tools
        ClipInspector(projectId: projectId),

        // Timeline at the bottom
        SizedBox(
          height: 220,
          child: TimelinePanel(projectId: projectId),
        ),
      ],
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onBack;

  const _ErrorView({required this.message, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, size: 48, color: AppTheme.danger),
          const SizedBox(height: 16),
          Text(
            'Proje yüklenemedi',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            message,
            style: const TextStyle(color: AppTheme.textSecondary),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          TextButton.icon(
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back),
            label: const Text('Geri'),
          ),
        ],
      ),
    );
  }
}
