import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/services/media_import_service.dart';
import '../../../data/services/permission_service.dart';
import '../../providers/editor_provider.dart';
import '../../providers/project_list_provider.dart';

/// Full-screen media picker.
///
/// Selection and import are separate steps:
/// 1. User selects one or more assets (checkmarks)
/// 2. User taps "Ekle" → import runs → result shown → pop on success
class MediaPickerScreen extends ConsumerStatefulWidget {
  final String projectId;

  const MediaPickerScreen({super.key, required this.projectId});

  @override
  ConsumerState<MediaPickerScreen> createState() => _MediaPickerScreenState();
}

class _MediaPickerScreenState extends ConsumerState<MediaPickerScreen> {
  PermissionState? _permissionState;
  List<AssetPathEntity> _albums = [];
  AssetPathEntity? _currentAlbum;
  List<AssetEntity> _assets = [];
  final Set<AssetEntity> _selected = {};
  bool _loading = true;
  bool _importing = false;
  String? _error;
  String _statusMessage = '';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final state = await PermissionService.requestPhotoAccess();
    if (!mounted) return;

    setState(() => _permissionState = state);

    if (!PermissionService.canAccessMedia(state)) {
      setState(() {
        _loading = false;
        _error = state == PermissionState.denied
            ? 'Medya erişim izni reddedildi'
            : 'Medya erişimi yok';
      });
      return;
    }

    try {
      final paths = await PhotoManager.getAssetPathList(
        type: RequestType.common, // images + videos
        onlyAll: false,
      );
      if (!mounted) return;

      if (paths.isEmpty) {
        setState(() {
          _loading = false;
          _albums = [];
          _assets = [];
        });
        return;
      }

      final allAlbum = paths.firstWhere(
        (p) => p.isAll,
        orElse: () => paths.first,
      );

      final assets = await allAlbum.getAssetListPaged(page: 0, size: 200);

      setState(() {
        _albums = paths;
        _currentAlbum = allAlbum;
        _assets = assets;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Medya listesi yüklenemedi: $e';
      });
    }
  }

  void _toggleSelection(AssetEntity asset) {
    setState(() {
      if (_selected.contains(asset)) {
        _selected.remove(asset);
      } else {
        _selected.add(asset);
      }
    });
  }

  Future<void> _onAddPressed() async {
    if (_selected.isEmpty || _importing) return;

    setState(() {
      _importing = true;
      _statusMessage = 'Dosyalar doğrulanıyor...';
    });

    try {
      final editorNotifier = ref.read(editorProvider(widget.projectId).notifier);
      final currentProject = ref.read(editorProvider(widget.projectId)).value;
      final timelineStart = currentProject?.durationMs ?? 0;

      final importService = MediaImportService(
        ref.read(projectRepositoryProvider),
      );

      setState(() => _statusMessage = 'İçe aktarılıyor...');

      final result = await importService.importAssets(
        projectId: widget.projectId,
        assets: _selected.toList(),
        timelineStartMs: timelineStart,
      );

      if (!mounted) return;

      if (result.added.isNotEmpty) {
        await editorNotifier.addClips(result.added);
      }

      if (!mounted) return;

      // Feedback
      if (result.isFullSuccess) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${result.added.length} medya eklendi'),
            backgroundColor: AppTheme.accent.withValues(alpha: 0.9),
          ),
        );
        Navigator.of(context).pop(true);
      } else if (result.hasPartialSuccess) {
        final failNames = result.failures.map((f) => f.originalName).join(', ');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${result.added.length} eklendi, ${result.failures.length} başarısız: $failNames',
            ),
            duration: const Duration(seconds: 5),
          ),
        );
        Navigator.of(context).pop(true);
      } else {
        final msg = result.failures.isNotEmpty
            ? result.failures.first.errorMessage ?? 'İçe aktarma başarısız'
            : 'Hiçbir dosya eklenemedi';
        setState(() {
          _importing = false;
          _statusMessage = '';
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: AppTheme.danger,
            ),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _importing = false;
        _statusMessage = '';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Beklenmeyen hata: $e'),
          backgroundColor: AppTheme.danger,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Medya Seç'),
        actions: [
          if (_selected.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Center(
                child: Text(
                  '${_selected.length} seçili',
                  style: const TextStyle(
                    color: AppTheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: _buildBody(),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: AppTheme.primary),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_outline, size: 48, color: AppTheme.danger),
              const SizedBox(height: 16),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppTheme.textPrimary),
              ),
              const SizedBox(height: 24),
              if (_permissionState == PermissionState.denied ||
                  _permissionState == PermissionState.restricted)
                ElevatedButton(
                  onPressed: () => PermissionService.openSettings(),
                  child: const Text('Ayarları Aç'),
                ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: _init,
                child: const Text('Tekrar Dene'),
              ),
            ],
          ),
        ),
      );
    }

    if (_assets.isEmpty) {
      return const Center(
        child: Text(
          'Galeride desteklenen medya bulunamadı',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
      );
    }

    return Column(
      children: [
        if (_importing)
          LinearProgressIndicator(
            backgroundColor: AppTheme.surface,
            color: AppTheme.primary,
          ),
        if (_statusMessage.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              _statusMessage,
              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 6,
              crossAxisSpacing: 6,
              childAspectRatio: 1,
            ),
            itemCount: _assets.length,
            itemBuilder: (context, index) {
              final asset = _assets[index];
              final isSelected = _selected.contains(asset);
              return _AssetThumb(
                asset: asset,
                isSelected: isSelected,
                onTap: _importing ? null : () => _toggleSelection(asset),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildBottomBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: const BoxDecoration(
          color: AppTheme.surface,
          border: Border(top: BorderSide(color: AppTheme.border)),
        ),
        child: Row(
          children: [
            TextButton(
              onPressed: _importing ? null : () => Navigator.of(context).pop(),
              child: const Text('İptal'),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: (_selected.isEmpty || _importing) ? null : _onAddPressed,
              icon: _importing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.add, size: 20),
              label: Text(_importing ? 'Ekleniyor...' : 'Ekle'),
            ),
          ],
        ),
      ),
    );
  }
}

class _AssetThumb extends StatelessWidget {
  final AssetEntity asset;
  final bool isSelected;
  final VoidCallback? onTap;

  const _AssetThumb({
    required this.asset,
    required this.isSelected,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        fit: StackFit.expand,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: AssetEntityImage(
              asset,
              isOriginal: false,
              thumbnailSize: const ThumbnailSize.square(200),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: AppTheme.surfaceElevated,
                child: const Icon(Icons.broken_image, color: AppTheme.textSecondary),
              ),
            ),
          ),
          // Video duration badge
          if (asset.type == AssetType.video)
            Positioned(
              left: 4,
              bottom: 4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  _formatDuration(asset.duration),
                  style: const TextStyle(color: Colors.white, fontSize: 10),
                ),
              ),
            ),
          // Selection overlay
          if (isSelected)
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.primary, width: 3),
                color: AppTheme.primary.withValues(alpha: 0.25),
              ),
            ),
          Positioned(
            top: 4,
            right: 4,
            child: Icon(
              isSelected ? Icons.check_circle : Icons.circle_outlined,
              color: isSelected ? AppTheme.primary : Colors.white70,
              size: 22,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }
}
