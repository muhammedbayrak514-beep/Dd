import 'dart:async';
import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_session.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:ffmpeg_kit_flutter_new/statistics.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../domain/export/export_plan.dart';
import '../../domain/models/project_model.dart';

enum ExportPhase {
  validating,
  encodingSegments,
  concatenating,
  applyingText,
  mixingAudio,
  done,
  failed,
  cancelled,
}

class ExportProgress {
  final ExportPhase phase;
  final String message;
  /// 0–1 when statistics available; null if unknown (no fake %)
  final double? fraction;
  final String? outputPath;
  final String? error;
  final List<String> warnings;

  const ExportProgress({
    required this.phase,
    required this.message,
    this.fraction,
    this.outputPath,
    this.error,
    this.warnings = const [],
  });
}

/// Real MP4 export via ffmpeg_kit_flutter_new.
///
/// Cancel: uses [FFmpegKit.executeAsync] so session id is known while running,
/// then [FFmpegKit.cancel].
class ExportService {
  bool _cancelRequested = false;
  int? _currentSessionId;
  bool _busy = false;
  final List<String> _warnings = [];

  bool get isBusy => _busy;

  void requestCancel() {
    _cancelRequested = true;
    final id = _currentSessionId;
    if (id != null) {
      FFmpegKit.cancel(id);
    } else {
      // Cancel all sessions if id not yet assigned
      FFmpegKit.cancel();
    }
  }

  Future<ExportProgress> export({
    required ProjectModel project,
    required void Function(ExportProgress) onProgress,
    ExportSettings settings = const ExportSettings(),
  }) async {
    if (_busy) {
      return const ExportProgress(
        phase: ExportPhase.failed,
        message: 'Zaten bir dışa aktarma çalışıyor',
        error: 'Başka bir export bitene kadar bekleyin',
      );
    }
    _busy = true;
    _cancelRequested = false;
    _warnings.clear();
    _currentSessionId = null;

    Directory? workDir;
    String? outputPath;

    try {
      onProgress(const ExportProgress(
        phase: ExportPhase.validating,
        message: 'Doğrulanıyor…',
      ));

      final plan = await ExportPlan.build(project, settings: settings);
      if (!plan.canExport) {
        final msg = plan.issues.map((e) => e.message).join('\n');
        return ExportProgress(
          phase: ExportPhase.failed,
          message: 'Doğrulama başarısız',
          error: msg.isEmpty ? 'Proje dışa aktarılamaz' : msg,
        );
      }

      final docs = await getApplicationDocumentsDirectory();
      final exportDir = Directory(p.join(docs.path, 'forge_edit_exports'));
      if (!await exportDir.exists()) await exportDir.create(recursive: true);

      workDir = Directory(p.join(docs.path, 'forge_edit_work', project.id));
      if (await workDir.exists()) {
        await workDir.delete(recursive: true);
      }
      await workDir.create(recursive: true);

      final stamp = DateTime.now().millisecondsSinceEpoch;
      final safeName =
          project.name.replaceAll(RegExp(r'[^\w\-.]'), '_');
      outputPath = p.join(exportDir.path, 'forgeedit_${safeName}_$stamp.mp4');

      // Use real timeline extent (max end), not sum of clip durations
      final totalDurationMs =
          plan.timelineDurationMs > 0 ? plan.timelineDurationMs : 3000;

      // 1) Segments
      final segmentPaths = <String>[];
      final segCmds = plan.buildSegmentCommands(
        workDir: workDir.path,
        segmentPathsOut: segmentPaths,
      );

      for (var i = 0; i < segCmds.length; i++) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(ExportProgress(
          phase: ExportPhase.encodingSegments,
          message: 'Klip ${i + 1}/${segCmds.length} kodlanıyor…',
          fraction: segCmds.isEmpty ? null : i / segCmds.length,
        ));

        final ok = await _runAsync(
          segCmds[i],
          onStats: (s) {
            final t = s.getTime();
            final dur = plan.videoTrack[i].durationMs;
            if (t > 0 && dur > 0) {
              final local = (t / dur).clamp(0.0, 1.0);
              onProgress(ExportProgress(
                phase: ExportPhase.encodingSegments,
                message: 'Klip ${i + 1}/${segCmds.length}…',
                fraction: (i + local) / segCmds.length,
              ));
            }
          },
        );
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        if (!ok) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: ExportPhase.failed,
            message: 'Klip kodlama başarısız',
            error: 'Segment $i FFmpeg hatası',
          );
        }
        final segFile = File(segmentPaths[i]);
        if (!await segFile.exists() || await segFile.length() == 0) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: ExportPhase.failed,
            message: 'Segment dosyası boş veya yok',
            error: segmentPaths[i],
          );
        }
        // Guarantee stereo AAC so concat never mixes A/V stream layouts
        final ensured = await _ensureSegmentHasAudio(
          segmentPaths[i],
          durationMs: plan.videoTrack[i].durationMs,
          settings: settings,
        );
        if (!ensured) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: ExportPhase.failed,
            message: 'Segment ses akışı oluşturulamadı',
            error: segmentPaths[i],
          );
        }
      }

      // 2) Concat
      if (_cancelRequested) {
        await _cleanupPartial(outputPath, workDir);
        return const ExportProgress(
          phase: ExportPhase.cancelled,
          message: 'İptal edildi',
        );
      }
      onProgress(const ExportProgress(
        phase: ExportPhase.concatenating,
        message: 'Birleştiriliyor…',
      ));

      var currentVideo = p.join(workDir.path, 'concat.mp4');
      if (segmentPaths.length == 1) {
        await File(segmentPaths.first).copy(currentVideo);
      } else if (segmentPaths.isEmpty) {
        final durSec = (totalDurationMs / 1000.0).clamp(0.5, 3600.0);
        final blackCmd =
            '-f lavfi -i color=c=black:s=${settings.width}x${settings.height}:d=${durSec.toStringAsFixed(2)} '
            '-c:v ${settings.videoCodec} -pix_fmt yuv420p -y "$currentVideo"';
        if (!await _runAsync(blackCmd)) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.failed,
            message: 'Boş video oluşturulamadı',
            error: 'lavfi color failed',
          );
        }
      } else {
        final listPath = p.join(workDir.path, 'concat.txt');
        await File(listPath)
            .writeAsString(plan.buildConcatListFile(segmentPaths));
        var ok = await _runAsync(
          '-f concat -safe 0 -i "$listPath" -c copy -y "$currentVideo"',
        );
        if (!ok) {
          ok = await _runAsync(
            '-f concat -safe 0 -i "$listPath" -c:v ${settings.videoCodec} '
            '-pix_fmt yuv420p -y "$currentVideo"',
          );
        }
        if (!ok || _cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return ExportProgress(
            phase: _cancelRequested
                ? ExportPhase.cancelled
                : ExportPhase.failed,
            message: _cancelRequested ? 'İptal edildi' : 'Birleştirme başarısız',
            error: _cancelRequested ? null : 'concat failed',
          );
        }
      }

      // 3) Text
      final draw = plan.buildDrawtextFilter();
      if (draw != null && draw.isNotEmpty) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(const ExportProgress(
          phase: ExportPhase.applyingText,
          message: 'Metin ekleniyor…',
        ));
        final withText = p.join(workDir.path, 'with_text.mp4');
        final fontArg = await _resolveFontFile();
        // fontFile is injected into each drawtext via buildDrawtextFilter
        final textVf = plan.buildDrawtextFilter(fontFile: fontArg) ?? draw;
        // Keep existing audio (-map 0:a?); do not use -an
        final textCmd =
            '-i "$currentVideo" -vf "$textVf" '
            '-map 0:v:0 -map 0:a? '
            '-c:v ${settings.videoCodec} -pix_fmt yuv420p '
            '-c:a aac -b:a 128k -y "$withText"';
        final ok = await _runAsync(textCmd);
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        if (ok && await File(withText).exists() && await File(withText).length() > 0) {
          currentVideo = withText;
        } else {
          _warnings.add(
            'Metin overlay uygulanamadı (font veya drawtext hatası). '
            'Video metinsiz kaydedildi.',
          );
        }
      }

      // 4) Audio — do NOT use -shortest (would cut video early)
      if (plan.audioTrack.isNotEmpty) {
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        onProgress(const ExportProgress(
          phase: ExportPhase.mixingAudio,
          message: 'Ses ekleniyor…',
        ));
        // Only first audio track is mixed (documented limitation)
        if (plan.audioTrack.length > 1) {
          _warnings.add(
            'Birden fazla ses klibi var; yalnızca ilki karıştırıldı.',
          );
        }
        final a = plan.audioTrack.first;
        final mixed = p.join(workDir.path, 'mixed.mp4');
        final aStart = (a.trimStartMs / 1000.0).toStringAsFixed(3);
        final aEnd = ((a.trimStartMs + a.durationMs) / 1000.0)
            .clamp(0.1, 3600.0)
            .toStringAsFixed(3);
        final vol = a.volume.clamp(0.0, 2.0).toStringAsFixed(2);
        final delayMs = a.timelineStartMs;
        final videoDurSec =
            (totalDurationMs / 1000.0).clamp(0.1, 3600.0).toStringAsFixed(3);

        // -ss/-t NOT applied before video -i.
        // Audio: atrim on input 1 only; adelay; pad to full timeline; never -shortest.
        // Mix with existing segment audio (0:a) if present.
        final audioCmd =
            '-i "$currentVideo" -i "${a.filePath}" '
            '-filter_complex '
            '"[1:a]atrim=$aStart:$aEnd,asetpts=PTS-STARTPTS,volume=$vol,'
            'adelay=${delayMs}|${delayMs},apad=whole_dur=$videoDurSec,'
            'atrim=0:$videoDurSec,asetpts=PTS-STARTPTS[bg];'
            '[0:a]apad=whole_dur=$videoDurSec,atrim=0:$videoDurSec,asetpts=PTS-STARTPTS[oa];'
            '[oa][bg]amix=inputs=2:duration=first:dropout_transition=0[a]" '
            '-map 0:v:0 -map "[a]" '
            '-c:v copy -c:a aac -t $videoDurSec -y "$mixed"';

        var ok = await _runAsync(audioCmd);
        if (!ok) {
          // Fallback: no original audio stream on video (e.g. failed map 0:a)
          final onlyBg =
              '-i "$currentVideo" -i "${a.filePath}" '
              '-filter_complex '
              '"[1:a]atrim=$aStart:$aEnd,asetpts=PTS-STARTPTS,volume=$vol,'
              'adelay=${delayMs}|${delayMs},apad=whole_dur=$videoDurSec,'
              'atrim=0:$videoDurSec,asetpts=PTS-STARTPTS[a]" '
              '-map 0:v:0 -map "[a]" '
              '-c:v copy -c:a aac -t $videoDurSec -y "$mixed"';
          ok = await _runAsync(onlyBg);
        }
        if (_cancelRequested) {
          await _cleanupPartial(outputPath, workDir);
          return const ExportProgress(
            phase: ExportPhase.cancelled,
            message: 'İptal edildi',
          );
        }
        if (ok && await File(mixed).exists() && await File(mixed).length() > 0) {
          currentVideo = mixed;
        } else {
          _warnings.add(
            'Ses karıştırılamadı; kaynak video sesi korunmaya çalışıldı.',
          );
        }
      }

      // Final copy + verify
      final outFile = File(outputPath);
      await File(currentVideo).copy(outputPath);
      if (!await outFile.exists() || await outFile.length() == 0) {
        await _cleanupPartial(outputPath, workDir);
        return const ExportProgress(
          phase: ExportPhase.failed,
          message: 'Çıktı dosyası boş veya yazılamadı',
          error: 'output missing',
        );
      }

      try {
        await workDir.delete(recursive: true);
      } catch (_) {}

      return ExportProgress(
        phase: ExportPhase.done,
        message: _warnings.isEmpty
            ? 'Tamamlandı'
            : 'Tamamlandı (uyarılarla)',
        fraction: 1.0,
        outputPath: outputPath,
        warnings: List.unmodifiable(_warnings),
      );
    } catch (e) {
      if (outputPath != null) {
        await _cleanupPartial(outputPath, workDir);
      }
      return ExportProgress(
        phase: ExportPhase.failed,
        message: 'Dışa aktarma hatası',
        error: e.toString(),
      );
    } finally {
      _busy = false;
      _currentSessionId = null;
    }
  }

  Future<void> _cleanupPartial(String? outputPath, Directory? workDir) async {
    try {
      if (outputPath != null) {
        final f = File(outputPath);
        if (await f.exists()) await f.delete();
      }
    } catch (_) {}
    try {
      if (workDir != null && await workDir.exists()) {
        await workDir.delete(recursive: true);
      }
    } catch (_) {}
  }

  /// Prefer Android system fonts that support Latin+Turkish.
  Future<String?> _resolveFontFile() async {
    const candidates = [
      '/system/fonts/Roboto-Regular.ttf',
      '/system/fonts/NotoSans-Regular.ttf',
      '/system/fonts/DroidSans.ttf',
      '/system/fonts/Roboto.ttf',
    ];
    for (final c in candidates) {
      if (await File(c).exists()) {
        // Escape for filter graph
        return c.replaceAll('\\', '/').replaceAll(':', '\\:');
      }
    }
    return null;
  }

  /// Async execute so [requestCancel] can target the live session id.
  Future<bool> _runAsync(
    String command, {
    void Function(Statistics)? onStats,
  }) async {
    if (_cancelRequested) return false;

    final completer = Completer<FFmpegSession>();

    final session = await FFmpegKit.executeAsync(
      command,
      (s) {
        if (!completer.isCompleted) completer.complete(s);
      },
      null,
      (Statistics statistics) {
        onStats?.call(statistics);
      },
    );

    _currentSessionId = await session.getSessionId();

    final finished = await completer.future;
    final code = await finished.getReturnCode();
    _currentSessionId = null;

    if (_cancelRequested || ReturnCode.isCancel(code)) {
      return false;
    }
    return ReturnCode.isSuccess(code);
  }
}
