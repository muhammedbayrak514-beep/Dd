import 'package:uuid/uuid.dart';

import 'models/clip_model.dart';
import 'models/project_model.dart';

/// Pure timeline operations. Main video track packing never moves audio/text.
class TimelineOps {
  static const _uuid = Uuid();
  static const int minTrimDurationMs = 100;

  static List<ClipModel> mainTrackClips(ProjectModel project) {
    final list =
        project.clips.where((c) => c.trackIndex == TrackIndex.video).toList()
          ..sort((a, b) => a.timelineStartMs.compareTo(b.timelineStartMs));
    return list;
  }

  /// Pack only track 0. Audio (1) and text (2) keep their timelineStartMs.
  static ProjectModel packMainTrack(ProjectModel project) {
    final main = mainTrackClips(project);
    final others =
        project.clips.where((c) => c.trackIndex != TrackIndex.video).toList();
    var cursor = 0;
    final packed = <ClipModel>[];
    for (final c in main) {
      packed.add(c.copyWith(timelineStartMs: cursor));
      cursor += c.durationMs;
    }
    return project.copyWith(
      clips: [...packed, ...others],
      updatedAt: DateTime.now(),
    );
  }

  static ProjectModel trimClip({
    required ProjectModel project,
    required String clipId,
    required int newTrimStartMs,
    required int newTrimEndMs,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return project;

    final maxSrc = clip.sourceDurationMs > 0 ? clip.sourceDurationMs : newTrimEndMs;
    var start = newTrimStartMs.clamp(0, maxSrc);
    var end = newTrimEndMs.clamp(0, maxSrc);
    if (end - start < minTrimDurationMs) {
      if (start + minTrimDurationMs <= maxSrc) {
        end = start + minTrimDurationMs;
      } else {
        start = (end - minTrimDurationMs).clamp(0, maxSrc);
      }
    }
    if (start >= end) return project;

    final updated = clip.copyWith(trimStartMs: start, trimEndMs: end);
    var next = project.updateClip(updated);
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next;
  }

  static ProjectModel? splitClip({
    required ProjectModel project,
    required String clipId,
    required int projectTimeMs,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return null;
    if (clip.type == ClipType.text) return null; // text: edit duration instead

    if (projectTimeMs <= clip.timelineStartMs ||
        projectTimeMs >= clip.timelineEndMs) {
      return null;
    }

    final offsetInClip = projectTimeMs - clip.timelineStartMs;
    // timeline duration accounts for speed: sourceDelta = offset * speed
    final sourceSplit =
        clip.trimStartMs + (offsetInClip * clip.speed).round();

    if (sourceSplit - clip.trimStartMs < minTrimDurationMs ||
        clip.trimEndMs - sourceSplit < minTrimDurationMs) {
      return null;
    }

    final left = clip.copyWith(trimEndMs: sourceSplit);

    final right = clip.copyWith(
      id: _uuid.v4(),
      displayName: '${clip.displayName} (2)',
      trimStartMs: sourceSplit,
      timelineStartMs: projectTimeMs,
    );

    final without = project.clips.where((c) => c.id != clipId).toList();
    var next = project.copyWith(
      clips: [...without, left, right],
      updatedAt: DateTime.now(),
    );
    if (clip.trackIndex == TrackIndex.video) {
      next = packMainTrack(next);
    }
    return next;
  }

  static ProjectModel deleteClip({
    required ProjectModel project,
    required String clipId,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    final next = project.removeClip(clipId);
    if (clip != null && clip.trackIndex == TrackIndex.video) {
      return packMainTrack(next);
    }
    return next.copyWith(updatedAt: DateTime.now());
  }

  static ProjectModel reorderMainTrack({
    required ProjectModel project,
    required String clipId,
    required int newIndex,
  }) {
    final main = mainTrackClips(project);
    final others =
        project.clips.where((c) => c.trackIndex != TrackIndex.video).toList();
    final from = main.indexWhere((c) => c.id == clipId);
    if (from < 0) return project;

    final item = main.removeAt(from);
    final to = newIndex.clamp(0, main.length);
    main.insert(to, item);

    var cursor = 0;
    final packed = <ClipModel>[];
    for (final c in main) {
      packed.add(c.copyWith(timelineStartMs: cursor));
      cursor += c.durationMs;
    }

    return project.copyWith(
      clips: [...packed, ...others],
      updatedAt: DateTime.now(),
    );
  }

  static ProjectModel moveClip({
    required ProjectModel project,
    required String clipId,
    required int direction,
  }) {
    final clip = project.clips.where((c) => c.id == clipId).firstOrNull;
    if (clip == null) return project;

    // Main track: reorder among video clips
    if (clip.trackIndex == TrackIndex.video) {
      final main = mainTrackClips(project);
      final from = main.indexWhere((c) => c.id == clipId);
      if (from < 0) return project;
      final to = from + direction;
      if (to < 0 || to >= main.length) return project;
      return reorderMainTrack(project: project, clipId: clipId, newIndex: to);
    }

    // Audio/text: nudge timelineStartMs by 500ms steps (simple Stage 6)
    const step = 500;
    final newStart =
        (clip.timelineStartMs + direction * step).clamp(0, 24 * 3600 * 1000);
    return project.updateClip(clip.copyWith(timelineStartMs: newStart));
  }
}

extension _FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull {
    final it = iterator;
    if (it.moveNext()) return it.current;
    return null;
  }
}
