import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

import 'clip_model.dart';

class ProjectModel extends Equatable {
  final String id;
  final String name;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<ClipModel> clips;

  /// Project-level settings
  final int frameRate; // e.g. 30
  final int width;
  final int height;

  const ProjectModel({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.updatedAt,
    this.clips = const [],
    this.frameRate = 30,
    this.width = 1920,
    this.height = 1080,
  });

  /// Total duration of the timeline (ms)
  int get durationMs {
    if (clips.isEmpty) return 0;
    return clips.map((c) => c.timelineEndMs).reduce((a, b) => a > b ? a : b);
  }

  ProjectModel copyWith({
    String? id,
    String? name,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<ClipModel>? clips,
    int? frameRate,
    int? width,
    int? height,
  }) {
    return ProjectModel(
      id: id ?? this.id,
      name: name ?? this.name,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      clips: clips ?? this.clips,
      frameRate: frameRate ?? this.frameRate,
      width: width ?? this.width,
      height: height ?? this.height,
    );
  }

  ProjectModel addClip(ClipModel clip) {
    final newClips = List<ClipModel>.from(clips)..add(clip);
    return copyWith(clips: newClips, updatedAt: DateTime.now());
  }

  ProjectModel removeClip(String clipId) {
    final newClips = clips.where((c) => c.id != clipId).toList();
    return copyWith(clips: newClips, updatedAt: DateTime.now());
  }

  ProjectModel updateClip(ClipModel updated) {
    final newClips = clips.map((c) => c.id == updated.id ? updated : c).toList();
    return copyWith(clips: newClips, updatedAt: DateTime.now());
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'clips': clips.map((c) => c.toJson()).toList(),
        'frameRate': frameRate,
        'width': width,
        'height': height,
      };

  factory ProjectModel.fromJson(Map<String, dynamic> json) {
    return ProjectModel(
      id: json['id'] as String,
      name: json['name'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
      clips: (json['clips'] as List<dynamic>)
          .map((e) => ClipModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      frameRate: json['frameRate'] as int? ?? 30,
      width: json['width'] as int? ?? 1920,
      height: json['height'] as int? ?? 1080,
    );
  }

  factory ProjectModel.create({String? name}) {
    final now = DateTime.now();
    return ProjectModel(
      id: const Uuid().v4(),
      name: name ?? 'Untitled Project',
      createdAt: now,
      updatedAt: now,
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        createdAt,
        updatedAt,
        clips,
        frameRate,
        width,
        height,
      ];
}
