import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// In-app approximation of FFmpeg xfade styles while swapping clips.
class TransitionOverlay extends StatelessWidget {
  final VideoPlayerController outgoing;
  final VideoPlayerController incoming;
  /// 0 = fully outgoing, 1 = fully incoming done.
  final double progress;
  final String kind;

  const TransitionOverlay({
    super.key,
    required this.outgoing,
    required this.incoming,
    required this.progress,
    required this.kind,
  });

  @override
  Widget build(BuildContext context) {
    final t = progress.clamp(0.0, 1.0);
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        final h = c.maxHeight;
        return Stack(
          fit: StackFit.expand,
          children: [
            // Incoming always at bottom
            _fit(incoming),
            // Outgoing transformed by kind
            _outgoingLayer(w, h, t),
          ],
        );
      },
    );
  }

  Widget _fit(VideoPlayerController c) {
    return Center(
      child: AspectRatio(
        aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
        child: VideoPlayer(c),
      ),
    );
  }

  Widget _outgoingLayer(double w, double h, double t) {
    final child = _fit(outgoing);

    switch (kind) {
      case 'fadeBlack':
        return Stack(
          fit: StackFit.expand,
          children: [
            Opacity(opacity: (1 - t).clamp(0.0, 1.0), child: child),
            Opacity(
              opacity: t < 0.5 ? t * 2 : (1 - t) * 2,
              child: const ColoredBox(color: Colors.black),
            ),
          ],
        );
      case 'fadeWhite':
        return Stack(
          fit: StackFit.expand,
          children: [
            Opacity(opacity: (1 - t).clamp(0.0, 1.0), child: child),
            Opacity(
              opacity: t < 0.5 ? t * 2 : (1 - t) * 2,
              child: const ColoredBox(color: Colors.white),
            ),
          ],
        );
      case 'wipeLeft':
        return ClipRect(
          clipper: _WipeClipper(axis: Axis.horizontal, fromStart: true, t: t),
          child: child,
        );
      case 'wipeRight':
        return ClipRect(
          clipper: _WipeClipper(axis: Axis.horizontal, fromStart: false, t: t),
          child: child,
        );
      case 'wipeUp':
        return ClipRect(
          clipper: _WipeClipper(axis: Axis.vertical, fromStart: false, t: t),
          child: child,
        );
      case 'wipeDown':
        return ClipRect(
          clipper: _WipeClipper(axis: Axis.vertical, fromStart: true, t: t),
          child: child,
        );
      case 'slideLeft':
        return Transform.translate(
          offset: Offset(-w * t, 0),
          child: Opacity(opacity: (1 - t * 0.3).clamp(0.0, 1.0), child: child),
        );
      case 'slideRight':
        return Transform.translate(
          offset: Offset(w * t, 0),
          child: Opacity(opacity: (1 - t * 0.3).clamp(0.0, 1.0), child: child),
        );
      case 'slideUp':
        return Transform.translate(
          offset: Offset(0, -h * t),
          child: Opacity(opacity: (1 - t * 0.3).clamp(0.0, 1.0), child: child),
        );
      case 'slideDown':
        return Transform.translate(
          offset: Offset(0, h * t),
          child: Opacity(opacity: (1 - t * 0.3).clamp(0.0, 1.0), child: child),
        );
      case 'circleOpen':
      case 'radial':
        return ClipPath(
          clipper: _CircleClipper(progress: t, open: true),
          child: child,
        );
      case 'circleClose':
        return ClipPath(
          clipper: _CircleClipper(progress: t, open: false),
          child: child,
        );
      case 'pixel':
      case 'fade':
      case 'crossfade':
      case 'dissolve':
      case 'hblur':
      case 'distance':
      default:
        return Opacity(opacity: (1 - t).clamp(0.0, 1.0), child: child);
    }
  }
}

class _WipeClipper extends CustomClipper<Rect> {
  final Axis axis;
  final bool fromStart;
  final double t;

  _WipeClipper({required this.axis, required this.fromStart, required this.t});

  @override
  Rect getClip(Size size) {
    final keep = (1 - t).clamp(0.0, 1.0);
    if (axis == Axis.horizontal) {
      if (fromStart) {
        // wipe left: shrink from left — remaining on the right
        return Rect.fromLTWH(size.width * t, 0, size.width * keep, size.height);
      }
      return Rect.fromLTWH(0, 0, size.width * keep, size.height);
    }
    if (fromStart) {
      return Rect.fromLTWH(0, size.height * t, size.width, size.height * keep);
    }
    return Rect.fromLTWH(0, 0, size.width, size.height * keep);
  }

  @override
  bool shouldReclip(covariant _WipeClipper old) =>
      old.t != t || old.axis != axis || old.fromStart != fromStart;
}

class _CircleClipper extends CustomClipper<Path> {
  final double progress;
  final bool open;

  _CircleClipper({required this.progress, required this.open});

  @override
  Path getClip(Size size) {
    final path = Path()..addRect(Offset.zero & size);
    final c = Offset(size.width / 2, size.height / 2);
    final maxR = math.sqrt(size.width * size.width + size.height * size.height) / 2;
    final r = open ? maxR * (1 - progress) : maxR * progress;
    // For open: reveal incoming by cutting outgoing with shrinking circle
    // even-odd: subtract circle from full rect when open
    final hole = Path()..addOval(Rect.fromCircle(center: c, radius: r.clamp(0.001, maxR)));
    if (open) {
      return Path.combine(PathOperation.difference, path, hole);
    }
    // close: outgoing only inside shrinking? show outgoing outside growing hole of incoming
    return Path.combine(PathOperation.difference, path, hole);
  }

  @override
  bool shouldReclip(covariant _CircleClipper old) =>
      old.progress != progress || old.open != open;
}
