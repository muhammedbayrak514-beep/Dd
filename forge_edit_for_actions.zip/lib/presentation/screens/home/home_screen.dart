import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../../domain/models/project_model.dart';
import '../../providers/project_list_provider.dart';
import '../editor/editor_screen.dart';
import '../../../domain/models/project_templates.dart';
import '../templates/template_gallery_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final projectsAsync = ref.watch(projectListProvider);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Header(onNewProject: () => _createNewProject(context, ref)),
              const SizedBox(height: 16),
              Material(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(14),
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const TemplateGalleryScreen(),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.border),
                      gradient: LinearGradient(
                        colors: [
                          AppTheme.primary.withValues(alpha: 0.15),
                          AppTheme.surface,
                        ],
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.dashboard_customize,
                            color: AppTheme.primary,
                          ),
                        ),
                        const SizedBox(width: 14),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Şablonlar',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'CapCut tarzı hazır video şablonları',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: AppTheme.textSecondary),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 88,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: ProjectTemplates.all.take(6).length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, i) {
                    final tpl = ProjectTemplates.all[i];
                    return InkWell(
                      onTap: () => _createFromTemplate(context, ref, tpl),
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        width: 140,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppTheme.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppTheme.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(tpl.icon, size: 20, color: tpl.accent),
                            const Spacer(),
                            Text(
                              tpl.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                            Text(
                              '${tpl.ratioLabel} · ${tpl.durationLabel}',
                              style: const TextStyle(
                                fontSize: 10,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: projectsAsync.when(
                  data: (projects) {
                    if (projects.isEmpty) {
                      return _EmptyState(
                        onCreate: () => _createNewProject(context, ref),
                      );
                    }
                    return _ProjectGrid(
                      projects: projects,
                      onOpen: (p) => _openProject(context, p),
                      onRename: (p) => _renameProject(context, ref, p),
                      onDelete: (id) =>
                          ref.read(projectListProvider.notifier).deleteProject(id),
                      onDuplicate: (p) => _duplicateProject(context, ref, p),
                    );
                  },
                  loading: () => const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  ),
                  error: (e, _) => Center(
                    child: Text(
                      'Projeler yüklenemedi: $e',
                      style: const TextStyle(color: AppTheme.danger),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _createNewProject(BuildContext context, WidgetRef ref) async {
    final project = await ref.read(projectListProvider.notifier).createProject();
    if (context.mounted) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => EditorScreen(projectId: project.id),
        ),
      );
    }
  }

  Future<void> _createFromTemplate(
    BuildContext context,
    WidgetRef ref,
    ProjectTemplate template,
  ) async {
    final project =
        await ref.read(projectListProvider.notifier).createFromTemplate(template);
    if (context.mounted) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => EditorScreen(projectId: project.id),
        ),
      );
    }
  }

  Future<void> _duplicateProject(
    BuildContext context,
    WidgetRef ref,
    ProjectModel project,
  ) async {
    final copy =
        await ref.read(projectListProvider.notifier).duplicateProject(project.id);
    if (copy != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kopyalandı: ${copy.name}')),
      );
    }
  }

  void _openProject(BuildContext context, ProjectModel project) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => EditorScreen(projectId: project.id),
      ),
    );
  }

  Future<void> _renameProject(
    BuildContext context,
    WidgetRef ref,
    ProjectModel project,
  ) async {
    final controller = TextEditingController(text: project.name);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Proje adı'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 48,
          decoration: const InputDecoration(hintText: 'Proje adı'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Kaydet'),
          ),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await ref.read(projectListProvider.notifier).renameProject(project.id, result);
  }
}

class _Header extends StatelessWidget {
  final VoidCallback onNewProject;

  const _Header({required this.onNewProject});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          'ForgeEdit',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
        ),
        const Spacer(),
        ElevatedButton.icon(
          onPressed: onNewProject,
          icon: const Icon(Icons.add, size: 20),
          label: const Text('Yeni Proje'),
        ),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onCreate;

  const _EmptyState({required this.onCreate});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.movie_creation_outlined,
            size: 80,
            color: AppTheme.textSecondary.withValues(alpha: 0.5),
          ),
          const SizedBox(height: 24),
          Text(
            'Henüz proje yok',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Yeni bir proje oluşturup videolarını düzenlemeye başla.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textSecondary,
                ),
          ),
          const SizedBox(height: 32),
          ElevatedButton.icon(
            onPressed: onCreate,
            icon: const Icon(Icons.add),
            label: const Text('İlk Projeyi Oluştur'),
          ),
        ],
      ),
    );
  }
}

class _ProjectGrid extends StatelessWidget {
  final List<ProjectModel> projects;
  final void Function(ProjectModel) onOpen;
  final void Function(ProjectModel) onRename;
  final void Function(String) onDelete;
  final void Function(ProjectModel) onDuplicate;

  const _ProjectGrid({
    required this.projects,
    required this.onOpen,
    required this.onRename,
    required this.onDelete,
    required this.onDuplicate,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 320,
        mainAxisSpacing: 20,
        crossAxisSpacing: 20,
        childAspectRatio: 1.4,
      ),
      itemCount: projects.length,
      itemBuilder: (context, index) {
        final p = projects[index];
        return _ProjectCard(
          project: p,
          onTap: () => onOpen(p),
          onRename: () => onRename(p),
          onDelete: () => onDelete(p.id),
          onDuplicate: () => onDuplicate(p),
        );
      },
    );
  }
}

class _ProjectCard extends StatelessWidget {
  final ProjectModel project;
  final VoidCallback onTap;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  final VoidCallback onDuplicate;

  const _ProjectCard({
    required this.project,
    required this.onTap,
    required this.onRename,
    required this.onDelete,
    required this.onDuplicate,
  });

  @override
  Widget build(BuildContext context) {
    final dateFmt = DateFormat('dd MMM yyyy, HH:mm');
    return Material(
      color: AppTheme.surfaceElevated,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        onLongPress: onRename,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.videocam_outlined, color: AppTheme.primary, size: 22),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      project.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(
                    onPressed: onDuplicate,
                    icon: const Icon(Icons.copy_outlined, size: 18),
                    color: AppTheme.textSecondary,
                    tooltip: 'Kopyala',
                  ),
                  IconButton(
                    onPressed: onRename,
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    color: AppTheme.textSecondary,
                    tooltip: 'Yeniden adlandır',
                  ),
                  IconButton(
                    onPressed: onDelete,
                    icon: const Icon(Icons.delete_outline, size: 20),
                    color: AppTheme.textSecondary,
                    tooltip: 'Sil',
                  ),
                ],
              ),
              const Spacer(),
              Text(
                '${project.clips.length} klip',
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
              ),
              const SizedBox(height: 4),
              Text(
                dateFmt.format(project.updatedAt),
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
