import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/services/export_service.dart';
import '../../../data/services/gallery_save_service.dart';
import '../../../domain/export/export_plan.dart';
import '../../../domain/export/export_error_messages.dart';
import '../../providers/editor_provider.dart';

class ExportScreen extends ConsumerStatefulWidget {
  final String projectId;

  const ExportScreen({super.key, required this.projectId});

  @override
  ConsumerState<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends ConsumerState<ExportScreen> {
  final _service = ExportService();
  ExportSettings _settings = const ExportSettings();
  ExportProgress? _progress;
  bool _running = false;
  bool _syncedFromProject = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_syncedFromProject) return;
    final project = ref.read(editorProvider(widget.projectId)).value;
    if (project != null) {
      _settings = ExportSettings(
        width: project.width,
        height: project.height,
        fps: project.frameRate,
        quality: 'balanced',
      );
      _syncedFromProject = true;
    }
  }

  Future<void> _start() async {
    if (_service.isBusy || _running) return;
    final project = ref.read(editorProvider(widget.projectId)).value;
    if (project == null) return;

    setState(() {
      _running = true;
      _progress = const ExportProgress(
        phase: ExportPhase.validating,
        message: 'Başlatılıyor…',
      );
    });

    final result = await _service.export(
      project: project,
      settings: _settings,
      onProgress: (p) {
        if (mounted) setState(() => _progress = p);
      },
    );

    if (!mounted) return;

    // FFmpeg writes only to app-private storage. Push into the system gallery
    // so the user sees the MP4 in Gallery / Google Photos / Files.
    ExportProgress finalProgress = result;
    if (result.phase == ExportPhase.done &&
        result.outputPath != null &&
        result.outputPath!.isNotEmpty) {
      setState(() {
        _progress = ExportProgress(
          phase: ExportPhase.done,
          message: 'Galeriye kaydediliyor…',
          fraction: 1,
          outputPath: result.outputPath,
          warnings: result.warnings,
        );
      });

      final save = await GallerySaveService.saveVideoToGallery(
        filePath: result.outputPath!,
        title: project.name,
      );

      if (!mounted) return;

      if (save.success) {
        final warnings = List<String>.from(result.warnings);
        finalProgress = ExportProgress(
          phase: ExportPhase.done,
          message: 'Galeriye kaydedildi',
          fraction: 1,
          outputPath: save.galleryPath ?? result.outputPath,
          warnings: warnings,
        );
      } else {
        final warnings = List<String>.from(result.warnings)
          ..add(
            save.error ??
                'Galeriye kopyalanamadı. Dosya uygulama klasöründe duruyor.',
          );
        finalProgress = ExportProgress(
          phase: ExportPhase.done,
          message: 'Export bitti (galeri kaydı başarısız)',
          fraction: 1,
          outputPath: result.outputPath,
          warnings: warnings,
        );
      }
    }

    if (mounted) {
      if (finalProgress.phase == ExportPhase.failed) {
        finalProgress = ExportProgress(
          phase: ExportPhase.failed,
          message: ExportErrorMessages.humanize(
            finalProgress.error ?? finalProgress.message,
          ),
          fraction: finalProgress.fraction,
          error: finalProgress.error,
          warnings: finalProgress.warnings,
        );
      }
      setState(() {
        _progress = finalProgress;
        _running = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final project = ref.watch(editorProvider(widget.projectId)).value;
    final p = _progress;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Dışa Aktar'),
        actions: [
          if (_running)
            TextButton(
              onPressed: () => _service.requestCancel(),
              child: const Text('İptal'),
            ),
        ],
      ),
      body: project == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text(
                  project.name,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'Motor: FFmpeg (ffmpeg_kit_flutter_new) · libx264 · MP4\n'
                  'Geçişler: 20 xfade stili (fade, wipe, slide, circle…).\n'
                  'Filtre, hız, döndürme segment aşamasında uygulanır.\n'
                  'Bittiğinde galeriye kaydedilir (Movies/ForgeEdit).',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 20),
                const Text('Çözünürlük',
                    style: TextStyle(fontWeight: FontWeight.w600)),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final res in [
                      (854, 480, '480p'),
                      (1280, 720, '720p'),
                      (1920, 1080, '1080p'),
                      (3840, 2160, '4K'),
                    ])
                      ChoiceChip(
                        label: Text('${res.$3} (${res.$1}×${res.$2})'),
                        selected: _settings.width == res.$1,
                        onSelected: _running
                            ? null
                            : (_) => setState(() {
                                  _settings = ExportSettings(
                                    width: res.$1,
                                    height: res.$2,
                                    fps: _settings.fps,
                                    quality: _settings.quality,
                                  );
                                }),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text('Kalite', style: TextStyle(fontWeight: FontWeight.w600)),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final q in [
                      ('draft', 'Hızlı'),
                      ('balanced', 'Dengeli'),
                      ('high', 'Yüksek'),
                    ])
                      ChoiceChip(
                        label: Text(q.$2),
                        selected: _settings.quality == q.$1,
                        onSelected: _running
                            ? null
                            : (_) => setState(() {
                                  _settings = ExportSettings(
                                    width: _settings.width,
                                    height: _settings.height,
                                    fps: _settings.fps,
                                    quality: q.$1,
                                  );
                                }),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text('FPS', style: TextStyle(fontWeight: FontWeight.w600)),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final fps in [24, 30])
                      ChoiceChip(
                        label: Text('$fps'),
                        selected: _settings.fps == fps,
                        onSelected: _running
                            ? null
                            : (_) => setState(() {
                                  _settings = ExportSettings(
                                    width: _settings.width,
                                    height: _settings.height,
                                    fps: fps,
                                    quality: _settings.quality,
                                  );
                                }),
                      ),
                  ],
                ),
                const SizedBox(height: 24),
                if (p != null) ...[
                  Text(p.message),
                  if (p.fraction != null) ...[
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: p.fraction),
                    Text('${(p.fraction! * 100).toStringAsFixed(0)}%'),
                  ] else if (_running)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: LinearProgressIndicator(),
                    ),
                  if (p.outputPath != null) ...[
                    const SizedBox(height: 12),
                    SelectableText(
                      'Dosya: ${p.outputPath}',
                      style: const TextStyle(color: AppTheme.accent),
                    ),
                  ],
                  if (p.error != null) ...[
                    const SizedBox(height: 8),
                    Text(p.error!, style: const TextStyle(color: AppTheme.danger)),
                  ],
                  if (p.warnings.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    ...p.warnings.map(
                      (w) => Text(w, style: const TextStyle(color: AppTheme.warning, fontSize: 12)),
                    ),
                  ],
                  const SizedBox(height: 16),
                ],
                ElevatedButton.icon(
                  onPressed: _running ? null : _start,
                  icon: const Icon(Icons.file_upload_outlined),
                  label: Text(_running ? 'İşleniyor…' : 'MP4 Olarak Dışa Aktar'),
                ),
              ],
            ),
    );
  }
}
