import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:photo_manager/photo_manager.dart';
import 'package:uuid/uuid.dart';

import '../../core/constants/app_constants.dart';
import '../../domain/models/clip_model.dart';
import '../repositories/project_repository.dart';
import 'proxy_service.dart';

/// Result of a single file import attempt.
class ImportResult {
  final bool success;
  final ClipModel? clip;
  final String? errorMessage;
  final String originalName;

  const ImportResult.success(this.clip, this.originalName)
      : success = true,
        errorMessage = null;

  const ImportResult.failure(this.originalName, this.errorMessage)
      : success = false,
        clip = null;
}

/// Aggregate result for a batch import.
class BatchImportResult {
  final List<ClipModel> added;
  final List<ImportResult> failures;
  final int totalRequested;

  const BatchImportResult({
    required this.added,
    required this.failures,
    required this.totalRequested,
  });

  bool get hasPartialSuccess => added.isNotEmpty && failures.isNotEmpty;
  bool get isFullSuccess => failures.isEmpty && added.isNotEmpty;
  bool get isFullFailure => added.isEmpty;
}

/// Handles importing media into a project.
///
/// Extension policy (strict):
/// - Prefer extension from asset.title
/// - Else from the real file path returned by asset.file
/// - If still unknown → fail with clear message (no silent .mp4 assumption)
/// - If extension is known but not in supported list → fail with clear message
class MediaImportService {
  final ProjectRepository _projectRepo;
  static const _uuid = Uuid();

  MediaImportService(this._projectRepo);

  Future<BatchImportResult> importAssets({
    required String projectId,
    required List<AssetEntity> assets,
    required int timelineStartMs,
  }) async {
    if (assets.isEmpty) {
      return const BatchImportResult(
        added: [],
        failures: [],
        totalRequested: 0,
      );
    }

    final mediaDirectory = await _projectRepo.mediaDir(projectId);
    final results = <ImportResult>[];
    final added = <ClipModel>[];
    var nextTimelineStart = timelineStartMs;

    for (final asset in assets) {
      final result = await _importSingle(
        asset: asset,
        mediaDir: mediaDirectory,
        timelineStartMs: nextTimelineStart,
      );
      results.add(result);
      if (result.success && result.clip != null) {
        added.add(result.clip!);
        nextTimelineStart = result.clip!.timelineEndMs;
      }
    }

    final failures = results.where((r) => !r.success).toList();
    return BatchImportResult(
      added: added,
      failures: failures,
      totalRequested: assets.length,
    );
  }

  Future<ImportResult> _importSingle({
    required AssetEntity asset,
    required Directory mediaDir,
    required int timelineStartMs,
  }) async {
    final displayName = asset.title ?? 'media_${asset.id}';

    try {
      // 1. Type
      final type = _mapAssetType(asset.type);
      if (type == null) {
        return ImportResult.failure(displayName, 'Desteklenmeyen medya türü');
      }

      // 2. Obtain real file (try multiple APIs — OEM / scoped storage differences)
      File? file = await asset.file;
      if (file == null || !await file.exists()) {
        try {
          file = await asset.originFile;
        } catch (_) {
          file = null;
        }
      }
      if (file == null || !await file.exists()) {
        return ImportResult.failure(
          displayName,
          'Dosyaya erişilemedi (izin veya depolama sorunu olabilir)',
        );
      }

      final fileSize = await file.length();
      if (fileSize == 0) {
        return ImportResult.failure(displayName, 'Dosya boş');
      }

      // 3. Resolve extension (title → path → mimeType fallback)
      final extResult = _resolveExtension(
        title: asset.title,
        filePath: file.path,
        mimeType: asset.mimeType,
        type: type,
      );
      if (extResult.error != null) {
        return ImportResult.failure(displayName, extResult.error!);
      }
      final ext = extResult.extension!;

      // 4. Duration — video: photo_manager seconds; image fixed 3s
      // Some OEMs report duration 0 for valid short clips → use 1s minimum
      int sourceDurationMs;
      if (asset.type == AssetType.video) {
        final fromAsset = asset.duration * 1000;
        sourceDurationMs = fromAsset > 0 ? fromAsset : 1000;
      } else {
        sourceDurationMs = 3000;
      }

      // 5. Copy into project-private media dir
      final clipId = _uuid.v4();
      final destPath = p.join(mediaDir.path, '$clipId.$ext');
      await file.copy(destPath);

      final destFile = File(destPath);
      if (!await destFile.exists() || await destFile.length() == 0) {
        return ImportResult.failure(displayName, 'Dosya kopyalanamadı');
      }

      final clip = ClipModel.fromImportedMedia(
        filePath: destPath,
        displayName: displayName,
        type: type,
        sourceDurationMs: sourceDurationMs,
        timelineStartMs: timelineStartMs,
        trackIndex: 0,
      );

      // Low-res proxy for smooth preview (export still uses original)
      if (type == ClipType.video) {
        // ignore: unawaited_futures
        ProxyService.generateProxyAsync(destPath);
      }

      return ImportResult.success(clip, displayName);
    } catch (e) {
      return ImportResult.failure(displayName, 'İçe aktarma hatası: $e');
    }
  }

  /// Resolves a safe lowercase extension.
  /// Order: title → real path → mimeType map. Never invent arbitrary names,
  /// but mime fallback covers content-URI paths without extensions.
  _ExtResult _resolveExtension({
    required String? title,
    required String filePath,
    required String? mimeType,
    required ClipType type,
  }) {
    String? fromTitle;
    if (title != null && title.contains('.')) {
      final e = p.extension(title).toLowerCase().replaceFirst('.', '');
      if (e.isNotEmpty) fromTitle = e;
    }

    String? fromPath;
    final pathExt = p.extension(filePath).toLowerCase().replaceFirst('.', '');
    if (pathExt.isNotEmpty) fromPath = pathExt;

    String? fromMime;
    final mime = (mimeType ?? '').toLowerCase();
    if (mime.isNotEmpty) {
      fromMime = _extensionFromMime(mime);
    }

    final ext = fromTitle ?? fromPath ?? fromMime;

    if (ext == null || ext.isEmpty) {
      return _ExtResult.error(
        'Dosya uzantısı belirlenemedi. Desteklenen biçimler: '
        '${_supportedList(type)}',
      );
    }

    final allowed = type == ClipType.video
        ? AppConstants.supportedVideoExtensions
        : type == ClipType.image
            ? AppConstants.supportedImageExtensions
            : <String>['mp3', 'm4a', 'aac', 'wav', 'ogg'];

    if (!allowed.contains(ext)) {
      return _ExtResult.error(
        '".$ext" biçimi desteklenmiyor. Desteklenen: ${allowed.join(", ")}',
      );
    }

    return _ExtResult.ok(ext);
  }

  String? _extensionFromMime(String mime) {
    const map = <String, String>{
      'video/mp4': 'mp4',
      'video/quicktime': 'mov',
      'video/x-matroska': 'mkv',
      'video/webm': 'webm',
      'video/3gpp': '3gp',
      'video/x-msvideo': 'avi',
      'video/avi': 'avi',
      'image/jpeg': 'jpg',
      'image/jpg': 'jpg',
      'image/png': 'png',
      'image/webp': 'webp',
      'image/heic': 'heic',
      'image/heif': 'heic',
      'audio/mpeg': 'mp3',
      'audio/mp4': 'm4a',
      'audio/aac': 'aac',
      'audio/wav': 'wav',
      'audio/x-wav': 'wav',
      'audio/ogg': 'ogg',
    };
    if (map.containsKey(mime)) return map[mime];
    // subtype only: "video/mp4; codecs=..." already lowercased without params ideally
    final base = mime.split(';').first.trim();
    return map[base];
  }

  String _supportedList(ClipType type) {
    switch (type) {
      case ClipType.video:
        return AppConstants.supportedVideoExtensions.join(', ');
      case ClipType.image:
        return AppConstants.supportedImageExtensions.join(', ');
      default:
        return 'mp3, m4a, aac, wav';
    }
  }

  ClipType? _mapAssetType(AssetType type) {
    switch (type) {
      case AssetType.video:
        return ClipType.video;
      case AssetType.image:
        return ClipType.image;
      case AssetType.audio:
        return ClipType.audio;
      default:
        return null;
    }
  }
}

class _ExtResult {
  final String? extension;
  final String? error;

  const _ExtResult.ok(this.extension) : error = null;
  const _ExtResult.error(this.error) : extension = null;
}
