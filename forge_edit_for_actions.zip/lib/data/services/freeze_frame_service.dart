import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../../domain/models/clip_model.dart';
import '../repositories/project_repository.dart';

class FreezeFrameService {
  final _uuid = const Uuid();
  final ProjectRepository _repo;

  FreezeFrameService({ProjectRepository? repo})
      : _repo = repo ?? ProjectRepository();

  /// Extract a still at [sourceTimeMs] from [sourcePath] into project media.
  Future<ClipModel?> capture({
    required String projectId,
    required String sourcePath,
    required int sourceTimeMs,
    required int timelineStartMs,
    int holdMs = 3000,
  }) async {
    final media = await _repo.mediaDir(projectId);
    final id = _uuid.v4();
    final out = p.join(media.path, '$id.jpg');
    final ss = (sourceTimeMs / 1000.0).clamp(0.0, 360000.0).toStringAsFixed(3);
    final cmd =
        '-ss $ss -i "$sourcePath" -frames:v 1 -q:v 2 -y "$out"';
    final session = await FFmpegKit.execute(cmd);
    final code = await session.getReturnCode();
    if (!ReturnCode.isSuccess(code) || !File(out).existsSync()) {
      return null;
    }
    return ClipModel.fromImportedMedia(
      filePath: out,
      displayName: 'Dondurulmuş kare',
      type: ClipType.image,
      sourceDurationMs: holdMs,
      timelineStartMs: timelineStartMs,
      trackIndex: TrackIndex.video,
    );
  }
}
