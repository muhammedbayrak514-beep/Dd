import 'package:hive_flutter/hive_flutter.dart';

/// Lightweight flags (onboarding, tips). Uses Hive box `app_prefs`.
class AppPrefs {
  static const _boxName = 'app_prefs';
  static const keyEditorOnboardingDone = 'editor_onboarding_v1_done';

  static Future<Box> _box() async {
    if (Hive.isBoxOpen(_boxName)) return Hive.box(_boxName);
    return Hive.openBox(_boxName);
  }

  static Future<bool> isEditorOnboardingDone() async {
    final b = await _box();
    return b.get(keyEditorOnboardingDone, defaultValue: false) == true;
  }

  static Future<void> setEditorOnboardingDone() async {
    final b = await _box();
    await b.put(keyEditorOnboardingDone, true);
  }
}
