class AppConstants {
  static const String appName = 'ForgeEdit';
  static const String packageName = 'com.forgeedit.app';

  /// Project files live under documents/projects/{projectId}/
  static const String projectsFolder = 'projects';

  /// Media copied into the project
  static const String mediaFolder = 'media';

  /// Supported video extensions (lowercase)
  static const List<String> supportedVideoExtensions = [
    'mp4',
    'mov',
    'mkv',
    'webm',
    '3gp',
    'avi',
    'm4v',
  ];

  /// Supported image extensions
  static const List<String> supportedImageExtensions = [
    'jpg',
    'jpeg',
    'png',
    'webp',
    'heic',
  ];

  /// Max file size warning threshold (500 MB)
  static const int maxFileSizeWarningBytes = 500 * 1024 * 1024;
}
