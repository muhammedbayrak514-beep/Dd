import 'models/project_model.dart';

/// Snapshot-based undo/redo stack with optional coalescing for continuous edits.
///
/// - Deep copies via JSON so snapshots are independent
/// - Max [maxDepth] undo entries
/// - New non-coalesced push clears redo
/// - Continuous gestures: [beginCoalesce] once, then [applyLive] without stacking,
///   or [pushBeforeChange] with same [coalesceKey] replaces last entry
class EditHistory {
  static const int maxDepth = 40;

  final List<ProjectModel> _undo = [];
  final List<ProjectModel> _redo = [];

  /// When non-null, the next discrete pushes with the same key replace the
  /// top of the undo stack instead of growing it (one logical undo for a drag).
  String? _activeCoalesceKey;
  bool _coalesceBaselinePushed = false;

  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;
  int get undoCount => _undo.length;
  int get redoCount => _redo.length;
  String? get activeCoalesceKey => _activeCoalesceKey;

  /// Start a continuous edit (slider drag). Pushes [before] once.
  void beginCoalesce(ProjectModel before, String key) {
    if (_activeCoalesceKey == key && _coalesceBaselinePushed) {
      return; // already baselined for this gesture
    }
    endCoalesce();
    _activeCoalesceKey = key;
    _undo.add(_clone(before));
    if (_undo.length > maxDepth) _undo.removeAt(0);
    _redo.clear();
    _coalesceBaselinePushed = true;
  }

  /// End continuous edit; next mutation is a normal push.
  void endCoalesce() {
    _activeCoalesceKey = null;
    _coalesceBaselinePushed = false;
  }

  /// Discrete mutation: always new undo step (unless same coalesce key active).
  void pushBeforeChange(ProjectModel before, {String? coalesceKey}) {
    if (coalesceKey != null &&
        coalesceKey == _activeCoalesceKey &&
        _coalesceBaselinePushed) {
      // Baseline already captured at beginCoalesce — do not stack
      return;
    }
    endCoalesce();
    _undo.add(_clone(before));
    if (_undo.length > maxDepth) _undo.removeAt(0);
    _redo.clear();
  }

  ProjectModel? undo(ProjectModel current) {
    endCoalesce();
    if (_undo.isEmpty) return null;
    _redo.add(_clone(current));
    return _undo.removeLast();
  }

  ProjectModel? redo(ProjectModel current) {
    endCoalesce();
    if (_redo.isEmpty) return null;
    _undo.add(_clone(current));
    if (_undo.length > maxDepth) _undo.removeAt(0);
    return _redo.removeLast();
  }

  void clear() {
    _undo.clear();
    _redo.clear();
    endCoalesce();
  }

  static ProjectModel _clone(ProjectModel p) =>
      ProjectModel.fromJson(p.toJson());
}

class HistoryUiState {
  final bool canUndo;
  final bool canRedo;
  final int undoCount;
  final int redoCount;

  const HistoryUiState({
    this.canUndo = false,
    this.canRedo = false,
    this.undoCount = 0,
    this.redoCount = 0,
  });

  factory HistoryUiState.from(EditHistory h) => HistoryUiState(
        canUndo: h.canUndo,
        canRedo: h.canRedo,
        undoCount: h.undoCount,
        redoCount: h.redoCount,
      );
}
