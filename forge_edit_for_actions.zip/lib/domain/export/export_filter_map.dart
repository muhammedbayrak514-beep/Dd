/// Maps ForgeEdit filter ids to FFmpeg video filter graph snippets.
/// Intensity 0–1 blends toward identity where possible.
class ExportFilterMap {
  /// Returns an FFmpeg -vf fragment (no leading/trailing commas).
  /// Empty string means no color filter.
  static String videoFilter(String filterId, double intensity) {
    final t = intensity.clamp(0.0, 1.0);
    if (filterId == 'none' || t <= 0) return '';

    switch (filterId) {
      case 'grayscale':
        // Full grayscale at t=1; partial via mix not trivial — use hue=s=
        final sat = (1.0 - t).toStringAsFixed(3);
        return 'hue=s=$sat';
      case 'sepia':
        // Approximate sepia via colorchannelmixer
        if (t < 0.05) return '';
        return 'colorchannelmixer='
            'rr=${_lerp(1, 0.393, t)}:rg=${_lerp(0, 0.769, t)}:rb=${_lerp(0, 0.189, t)}:'
            'gr=${_lerp(0, 0.349, t)}:gg=${_lerp(1, 0.686, t)}:gb=${_lerp(0, 0.168, t)}:'
            'br=${_lerp(0, 0.272, t)}:bg=${_lerp(0, 0.534, t)}:bb=${_lerp(1, 0.131, t)}';
      case 'warm':
        return 'eq=saturation=${_lerp(1, 1.15, t)}:gamma_r=${_lerp(1, 1.08, t)}';
      case 'cool':
        return 'eq=saturation=${_lerp(1, 1.05, t)}:gamma_b=${_lerp(1, 1.12, t)}';
      case 'highContrast':
        return 'eq=contrast=${_lerp(1, 1.4, t)}:brightness=${_lerp(0, -0.05, t)}';
      case 'muted':
        return 'eq=saturation=${_lerp(1, 0.45, t)}';
      case 'vivid':
        return 'eq=saturation=${_lerp(1, 1.55, t)}:contrast=${_lerp(1, 1.1, t)}';
      case 'vintage':
        return 'eq=saturation=${_lerp(1, 0.7, t)}:gamma=${_lerp(1, 1.1, t)}:'
            'brightness=${_lerp(0, 0.03, t)}';
      case 'bright':
        return 'eq=brightness=${_lerp(0, 0.12, t)}:contrast=${_lerp(1, 1.05, t)}';
      case 'noir':
        return 'hue=s=0,eq=contrast=${_lerp(1, 1.35, t)}:brightness=${_lerp(0, -0.08, t)}';
      case 'fade':
        return 'eq=saturation=${_lerp(1, 0.55, t)}:brightness=${_lerp(0, 0.06, t)}';
      case 'chromakey':
        // Green screen; similarity scales with intensity
        final sim = _lerp(0.08, 0.28, t);
        final blend = _lerp(0.02, 0.12, t);
        return 'chromakey=0x00FF00:$sim:$blend';
      default:
        return '';
    }
  }

  static String _lerp(num a, num b, double t) =>
      (a + (b - a) * t).toStringAsFixed(4);
}
