import 'dart:ui' show FontWeight, Offset;

import '../models/clip_model.dart';
import '../models/text_style_catalog.dart';

/// Maps a text [ClipModel] + catalog style into FFmpeg drawtext parameters.
///
/// Pure / testable — no I/O.
class ExportTextStyle {
  final String text;
  final int fontSize;
  final String fontcolor; // #RRGGBB
  final int x;
  final int y;
  final String startSec;
  final String endSec;
  final double shadowX;
  final double shadowY;
  final String? shadowColor; // black@0.7
  final bool preferBold;

  const ExportTextStyle({
    required this.text,
    required this.fontSize,
    required this.fontcolor,
    required this.x,
    required this.y,
    required this.startSec,
    required this.endSec,
    this.shadowX = 0,
    this.shadowY = 0,
    this.shadowColor,
    this.preferBold = false,
  });

  static String _escapeDrawtext(String raw) {
    return raw
        .replaceAll(r'\', r'\\')
        .replaceAll(':', r'\:')
        .replaceAll("'", r"\'")
        .replaceAll('%', r'\%');
  }

  static String _rgb(int argb) {
    final r = ((argb >> 16) & 0xFF).toRadixString(16).padLeft(2, '0');
    final g = ((argb >> 8) & 0xFF).toRadixString(16).padLeft(2, '0');
    final b = (argb & 0xFF).toRadixString(16).padLeft(2, '0');
    return '#$r$g$b';
  }

  static String _shadowRgba(int argb, {double alpha = 0.75}) {
    final r = (argb >> 16) & 0xFF;
    final g = (argb >> 8) & 0xFF;
    final b = argb & 0xFF;
    return '0x${r.toRadixString(16).padLeft(2, '0')}'
        '${g.toRadixString(16).padLeft(2, '0')}'
        '${b.toRadixString(16).padLeft(2, '0')}'
        '@${alpha.toStringAsFixed(2)}';
  }

  /// Build style snapshot for one text clip.
  static ExportTextStyle fromClip(
    ClipModel clip, {
    required int frameWidth,
    required int frameHeight,
  }) {
    final def = TextStyleCatalog.byId(clip.textStyleId);
    final raw = TextStyleResolver.displayText(clip.textContent, def);
    final colorArgb = def.presetColorArgb ?? clip.textColorArgb;
    final weight = def.weight;
    final preferBold = weight.value >= 600;

    double sx = 0, sy = 0;
    String? shadowCol;
    if (def.shadowBlur > 0 || def.shadowOffset != Offset.zero) {
      sx = def.shadowOffset.dx == 0 && def.shadowBlur > 0
          ? 2
          : def.shadowOffset.dx;
      sy = def.shadowOffset.dy == 0 && def.shadowBlur > 0
          ? 2
          : def.shadowOffset.dy;
      shadowCol = _shadowRgba(def.shadowColorArgb);
    }

    // Center-ish placement: pos is normalized 0–1 of frame.
    final x = (clip.posX * frameWidth).round().clamp(0, frameWidth);
    final y = (clip.posY * frameHeight).round().clamp(0, frameHeight);

    return ExportTextStyle(
      text: _escapeDrawtext(raw),
      fontSize: clip.fontSize.round().clamp(12, 200),
      fontcolor: _rgb(colorArgb),
      x: x,
      y: y,
      startSec: (clip.timelineStartMs / 1000.0).toStringAsFixed(3),
      endSec: (clip.timelineEndMs / 1000.0).toStringAsFixed(3),
      shadowX: sx,
      shadowY: sy,
      shadowColor: shadowCol,
      preferBold: preferBold,
    );
  }

  /// One drawtext=... fragment (no leading comma).
  String toDrawtext({String? fontFile}) {
    final fontPart =
        (fontFile != null && fontFile.isNotEmpty) ? ":fontfile=$fontFile" : '';
    final shadowPart = (shadowColor != null)
        ? ':shadowx=${shadowX.toStringAsFixed(1)}'
            ':shadowy=${shadowY.toStringAsFixed(1)}'
            ':shadowcolor=$shadowColor'
        : '';
    return "drawtext=text='$text':fontsize=$fontSize:fontcolor=$fontcolor:"
        "x=$x:y=$y$fontPart$shadowPart:enable='between(t\\,$startSec\\,$endSec)'";
  }
}

/// Builds the multi-input audio mix filter graph (testable).
///
/// Input 0 = video (with optional audio).
/// Inputs 1..N = audio clips in [clips] order.
class ExportAudioMix {
  /// Returns filter_complex string and whether it expects original video audio.
  static String build({
    required List<ClipModel> clips,
    required double videoDurSec,
  }) {
    if (clips.isEmpty) return '';
    final dur = videoDurSec.clamp(0.1, 3600.0).toStringAsFixed(3);
    final labels = <String>[];
    final parts = <String>[];

    // Original audio on video (input 0), padded to full length.
    parts.add(
      '[0:a]apad=whole_dur=$dur,atrim=0:$dur,asetpts=PTS-STARTPTS[oa]',
    );
    labels.add('[oa]');

    for (var i = 0; i < clips.length; i++) {
      final a = clips[i];
      final aStart = (a.trimStartMs / 1000.0).toStringAsFixed(3);
      final aEnd = ((a.trimStartMs + a.durationMs) / 1000.0)
          .clamp(0.1, 3600.0)
          .toStringAsFixed(3);
      final vol = a.volume.clamp(0.0, 2.0).toStringAsFixed(2);
      final delayMs = a.timelineStartMs.clamp(0, 24 * 3600 * 1000);
      final inIdx = i + 1;
      final lab = 'a$i';
      final fadeParts = <String>['volume=$vol'];
      if (a.fadeInMs > 0) {
        final fin = (a.fadeInMs / 1000.0).clamp(0.01, 30.0).toStringAsFixed(3);
        fadeParts.add('afade=t=in:st=0:d=$fin');
      }
      if (a.fadeOutMs > 0) {
        final clipDur = (a.durationMs / 1000.0).clamp(0.1, 3600.0);
        final fout = (a.fadeOutMs / 1000.0).clamp(0.01, 30.0);
        final st = (clipDur - fout).clamp(0.0, 3600.0).toStringAsFixed(3);
        fadeParts.add('afade=t=out:st=$st:d=${fout.toStringAsFixed(3)}');
      }
      final fadeChain = fadeParts.join(',');
      parts.add(
        '[$inIdx:a]atrim=$aStart:$aEnd,asetpts=PTS-STARTPTS,$fadeChain,'
        'adelay=$delayMs|$delayMs,apad=whole_dur=$dur,'
        'atrim=0:$dur,asetpts=PTS-STARTPTS[$lab]',
      );
      labels.add('[$lab]');
    }

    final n = labels.length;
    final joined = labels.join('');
    parts.add(
      '$joined'
      'amix=inputs=$n:duration=first:dropout_transition=0:normalize=0[aout]',
    );
    return parts.join(';');
  }

  /// Fallback when video has no audio stream: only mix the bg clips.
  static String buildBgOnly({
    required List<ClipModel> clips,
    required double videoDurSec,
  }) {
    if (clips.isEmpty) return '';
    final dur = videoDurSec.clamp(0.1, 3600.0).toStringAsFixed(3);
    final labels = <String>[];
    final parts = <String>[];
    for (var i = 0; i < clips.length; i++) {
      final a = clips[i];
      final aStart = (a.trimStartMs / 1000.0).toStringAsFixed(3);
      final aEnd = ((a.trimStartMs + a.durationMs) / 1000.0)
          .clamp(0.1, 3600.0)
          .toStringAsFixed(3);
      final vol = a.volume.clamp(0.0, 2.0).toStringAsFixed(2);
      final delayMs = a.timelineStartMs.clamp(0, 24 * 3600 * 1000);
      final inIdx = i + 1;
      final lab = 'a$i';
      final fadeParts = <String>['volume=$vol'];
      if (a.fadeInMs > 0) {
        final fin = (a.fadeInMs / 1000.0).clamp(0.01, 30.0).toStringAsFixed(3);
        fadeParts.add('afade=t=in:st=0:d=$fin');
      }
      if (a.fadeOutMs > 0) {
        final clipDur = (a.durationMs / 1000.0).clamp(0.1, 3600.0);
        final fout = (a.fadeOutMs / 1000.0).clamp(0.01, 30.0);
        final st = (clipDur - fout).clamp(0.0, 3600.0).toStringAsFixed(3);
        fadeParts.add('afade=t=out:st=$st:d=${fout.toStringAsFixed(3)}');
      }
      final fadeChain = fadeParts.join(',');
      parts.add(
        '[$inIdx:a]atrim=$aStart:$aEnd,asetpts=PTS-STARTPTS,$fadeChain,'
        'adelay=$delayMs|$delayMs,apad=whole_dur=$dur,'
        'atrim=0:$dur,asetpts=PTS-STARTPTS[$lab]',
      );
      labels.add('[$lab]');
    }
    if (labels.length == 1) {
      parts.add('${labels.first}anull[aout]');
      return parts.join(';');
    }
    final joined = labels.join('');
    parts.add(
      '$joined'
      'amix=inputs=${labels.length}:duration=first:dropout_transition=0:normalize=0[aout]',
    );
    return parts.join(';');
  }
}
