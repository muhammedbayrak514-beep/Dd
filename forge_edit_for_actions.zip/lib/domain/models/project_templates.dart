import 'package:flutter/material.dart';

import 'clip_model.dart';

/// One media slot the user is expected to fill (CapCut-style).
class TemplateMediaSlot {
  final String label;
  final int startMs;
  final int durationMs;

  const TemplateMediaSlot({
    required this.label,
    required this.startMs,
    required this.durationMs,
  });
}

/// CapCut-style template definition.
class ProjectTemplate {
  final String id;
  final String title;
  final String subtitle;
  final String category;
  final int width;
  final int height;
  final int durationMs;
  final int mediaSlots;
  final List<String> tags;
  final IconData icon;
  final Color accent;
  final bool isNew;
  final bool isHot;
  /// easy | medium | pro
  final String difficulty;
  final List<TemplateMediaSlot> slots;
  final List<ClipModel> Function() buildClips;

  const ProjectTemplate({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.category,
    required this.width,
    required this.height,
    required this.durationMs,
    required this.mediaSlots,
    required this.tags,
    required this.icon,
    required this.accent,
    required this.buildClips,
    this.slots = const [],
    this.isNew = false,
    this.isHot = false,
    this.difficulty = 'easy',
  });

  String get ratioLabel {
    if (width == 1080 && height == 1920) return '9:16';
    if (width == 1080 && height == 1080) return '1:1';
    if (width == 1920 && height == 1080) return '16:9';
    if (width == 1080 && height == 1350) return '4:5';
    return '$width×$height';
  }

  String get durationLabel {
    final s = (durationMs / 1000).round();
    return '${s}s';
  }

  String get difficultyLabel {
    switch (difficulty) {
      case 'pro':
        return 'Pro';
      case 'medium':
        return 'Orta';
      default:
        return 'Kolay';
    }
  }

  /// Guide text clips for empty media slots (shown until user adds video).
  List<ClipModel> buildSlotGuides() {
    if (slots.isEmpty) return const [];
    return [
      for (final s in slots)
        ClipModel.text(
          content: '▶ ${s.label}',
          durationMs: s.durationMs.clamp(500, 60000),
          timelineStartMs: s.startMs,
          fontSize: 22,
          posY: 0.12,
        ).copyWith(
          textAnimId: 'fadeIn',
          colorTag: 'blue',
          trackIndex: TrackIndex.sticker,
          displayName: s.label,
        ),
    ];
  }

  List<ClipModel> buildAllClips() => [...buildClips(), ...buildSlotGuides()];
}

class ProjectTemplates {
  static const categories = [
    'Tümü',
    'Trend',
    'Reels',
    'Story',
    'Promo',
    'Sinematik',
    'Eğitim',
    'Müzik',
  ];

  static List<ProjectTemplate> byCategory(String category) {
    if (category == 'Tümü') return all;
    return all.where((t) => t.category == category).toList();
  }

  static List<ProjectTemplate> get featured =>
      all.where((t) => t.isHot || t.isNew).toList();

  static ProjectTemplate? byId(String id) {
    for (final t in all) {
      if (t.id == id) return t;
    }
    return null;
  }

  // ── helpers ──────────────────────────────────────────────
  static ClipModel _t(
    String text, {
    required int start,
    required int dur,
    double size = 36,
    double y = 0.5,
    String anim = 'fadeIn',
    String transition = 'none',
    int fadeIn = 0,
    int fadeOut = 0,
    String tag = 'none',
  }) {
    return ClipModel.text(
      content: text,
      durationMs: dur,
      timelineStartMs: start,
      fontSize: size,
      posY: y,
    ).copyWith(
      textAnimId: anim,
      transitionId: transition,
      fadeInMs: fadeIn,
      fadeOutMs: fadeOut,
      colorTag: tag,
    );
  }

  static final all = <ProjectTemplate>[
    // ══════════ TREND ══════════
    ProjectTemplate(
      id: 'trend_hook',
      title: '3sn Hook',
      subtitle: 'İlk saniyede dikkat çek',
      category: 'Trend',
      width: 1080,
      height: 1920,
      durationMs: 3000,
      mediaSlots: 1,
      tags: ['viral', 'hook'],
      icon: Icons.bolt,
      accent: const Color(0xFFFF4D6A),
      isHot: true,
      slots: [TemplateMediaSlot(label: 'Ana video', startMs: 0, durationMs: 3000)],
      buildClips: () => [
        _t('DUR!', start: 0, dur: 1500, size: 72, y: 0.4, anim: 'slideUp', transition: 'crossfade'),
        _t('Bunu kaçırma', start: 1500, dur: 1500, size: 36, y: 0.55, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'trend_countdown',
      title: 'Geri Sayım',
      subtitle: '3 · 2 · 1 · GO',
      category: 'Trend',
      width: 1080,
      height: 1920,
      durationMs: 4000,
      mediaSlots: 1,
      tags: ['countdown'],
      icon: Icons.timer,
      accent: const Color(0xFFFFB020),
      isHot: true,
      slots: [TemplateMediaSlot(label: 'Arka plan', startMs: 0, durationMs: 4000)],
      buildClips: () => [
        for (var i = 0; i < 3; i++)
          _t('${3 - i}', start: i * 800, dur: 800, size: 96, y: 0.45, anim: 'fadeInOut'),
        _t('GO!', start: 2400, dur: 1600, size: 80, y: 0.45, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'trend_before_after',
      title: 'Önce / Sonra',
      subtitle: 'İki sahne karşılaştırma',
      category: 'Trend',
      width: 1080,
      height: 1920,
      durationMs: 6000,
      mediaSlots: 2,
      tags: ['before', 'after'],
      icon: Icons.compare,
      accent: const Color(0xFF5B8CFF),
      difficulty: 'medium',
      slots: [
        TemplateMediaSlot(label: 'Önce videosu', startMs: 0, durationMs: 3000),
        TemplateMediaSlot(label: 'Sonra videosu', startMs: 3000, durationMs: 3000),
      ],
      buildClips: () => [
        _t('ÖNCE', start: 0, dur: 3000, size: 48, y: 0.2, anim: 'fadeIn', transition: 'wipeLeft'),
        _t('SONRA', start: 3000, dur: 3000, size: 48, y: 0.2, anim: 'slideLeft'),
      ],
    ),
    ProjectTemplate(
      id: 'trend_listicle',
      title: 'Top 5 Liste',
      subtitle: '5 madde, hızlı kesimler',
      category: 'Trend',
      width: 1080,
      height: 1920,
      durationMs: 10000,
      mediaSlots: 5,
      tags: ['list', 'top5'],
      icon: Icons.format_list_numbered,
      accent: const Color(0xFFE879F9),
      isNew: true,
      difficulty: 'medium',
      slots: [
        for (var i = 0; i < 5; i++)
          TemplateMediaSlot(label: 'Madde ${i + 1} videosu', startMs: i * 2000, durationMs: 2000),
      ],
      buildClips: () => [
        for (var i = 0; i < 5; i++)
          _t('${i + 1}. Madde', start: i * 2000, dur: 2000, size: 40, y: 0.75, anim: 'slideUp', transition: i < 4 ? 'crossfade' : 'none'),
      ],
    ),
    ProjectTemplate(
      id: 'trend_pov',
      title: 'POV',
      subtitle: 'POV: sen …',
      category: 'Trend',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['pov', 'meme'],
      icon: Icons.visibility,
      accent: const Color(0xFF22D3EE),
      isNew: true,
      slots: [TemplateMediaSlot(label: 'POV videosu', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('POV', start: 0, dur: 2000, size: 64, y: 0.3, anim: 'fadeIn'),
        _t('Sen bunu izliyorsun', start: 1500, dur: 3500, size: 32, y: 0.5, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'trend_green_screen',
      title: 'Yeşil Ekran',
      subtitle: 'Chroma + metin katmanı',
      category: 'Trend',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['chroma', 'green'],
      icon: Icons.filter_center_focus,
      accent: const Color(0xFF22C55E),
      difficulty: 'pro',
      slots: [TemplateMediaSlot(label: 'Yeşil ekran videosu', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('Yeşil ekran ekle', start: 0, dur: 5000, size: 28, y: 0.2, anim: 'fadeIn'),
        _t('Efekt → Yeşil ekran', start: 0, dur: 5000, size: 22, y: 0.85, anim: 'fadeIn'),
      ],
    ),

    // ══════════ REELS ══════════
    ProjectTemplate(
      id: 'reels_intro',
      title: 'Reels Intro',
      subtitle: 'Başlık + altyazı',
      category: 'Reels',
      width: 1080,
      height: 1920,
      durationMs: 3000,
      mediaSlots: 1,
      tags: ['intro'],
      icon: Icons.movie_filter,
      accent: const Color(0xFFE879F9),
      isHot: true,
      slots: [TemplateMediaSlot(label: 'Intro videosu', startMs: 0, durationMs: 3000)],
      buildClips: () => [
        _t('BAŞLIK', start: 0, dur: 3000, size: 56, y: 0.35, anim: 'slideUp'),
        _t('Altyazı buraya', start: 0, dur: 3000, size: 28, y: 0.55, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'reels_caption_beat',
      title: 'Altyazı Beat',
      subtitle: '4 satır ritmik metin',
      category: 'Reels',
      width: 1080,
      height: 1920,
      durationMs: 8000,
      mediaSlots: 1,
      tags: ['caption'],
      icon: Icons.subtitles,
      accent: const Color(0xFF22C55E),
      slots: [TemplateMediaSlot(label: 'Ana video', startMs: 0, durationMs: 8000)],
      buildClips: () => [
        for (var i = 0; i < 4; i++)
          _t('Satır ${i + 1}', start: i * 2000, dur: 2000, size: 34, y: 0.78, anim: i.isEven ? 'slideUp' : 'fadeIn', transition: i < 3 ? 'crossfade' : 'none'),
      ],
    ),
    ProjectTemplate(
      id: 'reels_product',
      title: 'Ürün Vitrin',
      subtitle: 'İsim · fiyat · CTA',
      category: 'Reels',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['shop', 'cta'],
      icon: Icons.shopping_bag,
      accent: const Color(0xFFFFB020),
      slots: [TemplateMediaSlot(label: 'Ürün videosu', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('Ürün Adı', start: 0, dur: 5000, size: 42, y: 0.25, anim: 'slideUp'),
        _t('₺299', start: 800, dur: 4000, size: 48, y: 0.4, anim: 'fadeIn'),
        _t('Şimdi al →', start: 1500, dur: 3500, size: 28, y: 0.85, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'reels_day_in_life',
      title: 'Bir Günüm',
      subtitle: 'Sabah · öğle · akşam',
      category: 'Reels',
      width: 1080,
      height: 1920,
      durationMs: 9000,
      mediaSlots: 3,
      tags: ['vlog', 'day'],
      icon: Icons.wb_sunny,
      accent: const Color(0xFFFFB020),
      isNew: true,
      difficulty: 'medium',
      slots: [
        TemplateMediaSlot(label: 'Sabah', startMs: 0, durationMs: 3000),
        TemplateMediaSlot(label: 'Öğle', startMs: 3000, durationMs: 3000),
        TemplateMediaSlot(label: 'Akşam', startMs: 6000, durationMs: 3000),
      ],
      buildClips: () => [
        _t('SABAH', start: 0, dur: 3000, size: 40, y: 0.2, anim: 'fadeIn', transition: 'fadeBlack'),
        _t('ÖĞLE', start: 3000, dur: 3000, size: 40, y: 0.2, anim: 'slideLeft', transition: 'crossfade'),
        _t('AKŞAM', start: 6000, dur: 3000, size: 40, y: 0.2, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'reels_qa',
      title: 'Soru-Cevap',
      subtitle: 'Soru → cevap ritmi',
      category: 'Reels',
      width: 1080,
      height: 1920,
      durationMs: 6000,
      mediaSlots: 1,
      tags: ['qa'],
      icon: Icons.question_answer,
      accent: const Color(0xFF5B8CFF),
      slots: [TemplateMediaSlot(label: 'Cevap videosu', startMs: 2000, durationMs: 4000)],
      buildClips: () => [
        _t('Soru nedir?', start: 0, dur: 2000, size: 36, y: 0.4, anim: 'fadeIn', transition: 'wipeLeft'),
        _t('Cevap burada', start: 2000, dur: 4000, size: 34, y: 0.75, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'reels_transition_pack',
      title: 'Geçiş Paketi',
      subtitle: '4 klip, soft geçişler',
      category: 'Reels',
      width: 1080,
      height: 1920,
      durationMs: 8000,
      mediaSlots: 4,
      tags: ['transition'],
      icon: Icons.animation,
      accent: const Color(0xFFA855F7),
      difficulty: 'medium',
      slots: [
        for (var i = 0; i < 4; i++)
          TemplateMediaSlot(label: 'Klip ${i + 1}', startMs: i * 2000, durationMs: 2000),
      ],
      buildClips: () => [
        for (var i = 0; i < 4; i++)
          _t('Sahne ${i + 1}', start: i * 2000, dur: 2000, size: 32, y: 0.85, anim: 'fadeIn', transition: i < 3 ? 'crossfade' : 'none'),
      ],
    ),

    // ══════════ STORY ══════════
    ProjectTemplate(
      id: 'story_beat',
      title: '3 Sahne Story',
      subtitle: 'Sahne sahne anlat',
      category: 'Story',
      width: 1080,
      height: 1920,
      durationMs: 7500,
      mediaSlots: 3,
      tags: ['story'],
      icon: Icons.auto_stories,
      accent: const Color(0xFFA855F7),
      slots: [
        TemplateMediaSlot(label: 'Sahne 1', startMs: 0, durationMs: 2500),
        TemplateMediaSlot(label: 'Sahne 2', startMs: 2500, durationMs: 2500),
        TemplateMediaSlot(label: 'Sahne 3', startMs: 5000, durationMs: 2500),
      ],
      buildClips: () => [
        _t('1. Sahne', start: 0, dur: 2500, size: 42, y: 0.45, anim: 'fadeIn', transition: 'fadeBlack'),
        _t('2. Sahne', start: 2500, dur: 2500, size: 42, y: 0.45, anim: 'slideLeft', transition: 'crossfade'),
        _t('3. Sahne', start: 5000, dur: 2500, size: 42, y: 0.45, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'story_quote',
      title: 'Alıntı Kartı',
      subtitle: 'Tek cümle, güçlü vurgu',
      category: 'Story',
      width: 1080,
      height: 1920,
      durationMs: 4000,
      mediaSlots: 1,
      tags: ['quote'],
      icon: Icons.format_quote,
      accent: const Color(0xFF5B8CFF),
      slots: [TemplateMediaSlot(label: 'Arka plan', startMs: 0, durationMs: 4000)],
      buildClips: () => [
        _t('"Buraya alıntı"', start: 0, dur: 4000, size: 36, y: 0.45, anim: 'fadeInOut', fadeIn: 400, fadeOut: 400),
        _t('— Yazar', start: 1000, dur: 3000, size: 22, y: 0.6, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'story_poll',
      title: 'Anket Story',
      subtitle: 'A mı B mi?',
      category: 'Story',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['poll'],
      icon: Icons.poll,
      accent: const Color(0xFFFF4D6A),
      isNew: true,
      slots: [TemplateMediaSlot(label: 'Arka plan', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('Sen olsan?', start: 0, dur: 5000, size: 40, y: 0.3, anim: 'slideUp'),
        _t('A) Seçenek 1', start: 800, dur: 4200, size: 30, y: 0.5, anim: 'fadeIn'),
        _t('B) Seçenek 2', start: 1200, dur: 3800, size: 30, y: 0.6, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'story_mood',
      title: 'Mood Board',
      subtitle: '4 kare his',
      category: 'Story',
      width: 1080,
      height: 1920,
      durationMs: 8000,
      mediaSlots: 4,
      tags: ['mood'],
      icon: Icons.grid_view,
      accent: const Color(0xFFE879F9),
      difficulty: 'medium',
      slots: [
        for (var i = 0; i < 4; i++)
          TemplateMediaSlot(label: 'Mood ${i + 1}', startMs: i * 2000, durationMs: 2000),
      ],
      buildClips: () => [
        for (var i = 0; i < 4; i++)
          _t(['Mutlu', 'Odak', 'Enerji', 'Sakin'][i], start: i * 2000, dur: 2000, size: 36, y: 0.8, anim: 'fadeIn', transition: i < 3 ? 'dissolve' : 'none'),
      ],
    ),

    // ══════════ PROMO ══════════
    ProjectTemplate(
      id: 'promo_sale',
      title: 'İndirim Bombası',
      subtitle: '%50 · acele et',
      category: 'Promo',
      width: 1080,
      height: 1920,
      durationMs: 4500,
      mediaSlots: 1,
      tags: ['sale'],
      icon: Icons.local_offer,
      accent: const Color(0xFFFF4D6A),
      isHot: true,
      slots: [TemplateMediaSlot(label: 'Ürün görseli/video', startMs: 0, durationMs: 4500)],
      buildClips: () => [
        _t('%50', start: 0, dur: 4500, size: 96, y: 0.35, anim: 'slideUp'),
        _t('İNDİRİM', start: 400, dur: 4000, size: 40, y: 0.5, anim: 'fadeIn'),
        _t('Bugün son!', start: 1200, dur: 3000, size: 28, y: 0.82, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'promo_announce',
      title: 'Duyuru',
      subtitle: 'Yeni özellik / etkinlik',
      category: 'Promo',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['announce'],
      icon: Icons.campaign,
      accent: const Color(0xFF22D3EE),
      slots: [TemplateMediaSlot(label: 'Görsel', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('YENİ', start: 0, dur: 5000, size: 28, y: 0.3, anim: 'fadeIn'),
        _t('Duyuru başlığı', start: 0, dur: 5000, size: 44, y: 0.42, anim: 'slideUp'),
        _t('Detay satırı buraya', start: 800, dur: 4000, size: 24, y: 0.55, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'square_post',
      title: 'Kare Post',
      subtitle: '1:1 sosyal medya',
      category: 'Promo',
      width: 1080,
      height: 1080,
      durationMs: 4000,
      mediaSlots: 1,
      tags: ['square', 'feed'],
      icon: Icons.crop_square,
      accent: const Color(0xFF22C55E),
      slots: [TemplateMediaSlot(label: 'Görsel', startMs: 0, durationMs: 4000)],
      buildClips: () => [
        _t('POST', start: 0, dur: 4000, size: 64, y: 0.5, anim: 'fadeInOut'),
      ],
    ),
    ProjectTemplate(
      id: 'promo_app_launch',
      title: 'Uygulama Lansmanı',
      subtitle: 'İndir · keşfet · başla',
      category: 'Promo',
      width: 1080,
      height: 1920,
      durationMs: 6000,
      mediaSlots: 2,
      tags: ['app', 'launch'],
      icon: Icons.phone_android,
      accent: const Color(0xFF5B8CFF),
      isNew: true,
      difficulty: 'medium',
      slots: [
        TemplateMediaSlot(label: 'Uygulama ekranı 1', startMs: 0, durationMs: 3000),
        TemplateMediaSlot(label: 'Uygulama ekranı 2', startMs: 3000, durationMs: 3000),
      ],
      buildClips: () => [
        _t('Yeni uygulama', start: 0, dur: 3000, size: 36, y: 0.25, anim: 'slideUp', transition: 'crossfade'),
        _t('Hemen indir', start: 3000, dur: 3000, size: 40, y: 0.8, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'promo_review',
      title: 'Müşteri Yorumu',
      subtitle: '5 yıldız + alıntı',
      category: 'Promo',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['review'],
      icon: Icons.star,
      accent: const Color(0xFFFFB020),
      slots: [TemplateMediaSlot(label: 'Ürün/ortam', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('★★★★★', start: 0, dur: 5000, size: 36, y: 0.35, anim: 'fadeIn'),
        _t('"Harika ürün!"', start: 500, dur: 4500, size: 32, y: 0.5, anim: 'slideUp'),
        _t('— Mutlu müşteri', start: 1200, dur: 3800, size: 20, y: 0.62, anim: 'fadeIn'),
      ],
    ),

    // ══════════ SİNEMATİK ══════════
    ProjectTemplate(
      id: 'cine_title',
      title: 'Film Başlığı',
      subtitle: '16:9 sinematik açılış',
      category: 'Sinematik',
      width: 1920,
      height: 1080,
      durationMs: 6000,
      mediaSlots: 1,
      tags: ['cinematic'],
      icon: Icons.theaters,
      accent: const Color(0xFF94A3B8),
      difficulty: 'medium',
      slots: [TemplateMediaSlot(label: 'B-roll', startMs: 0, durationMs: 6000)],
      buildClips: () => [
        _t('FİLM ADI', start: 500, dur: 5000, size: 56, y: 0.45, anim: 'fadeIn', fadeIn: 800, fadeOut: 600),
        _t('Bir alt başlık', start: 1500, dur: 4000, size: 24, y: 0.58, anim: 'fadeIn', fadeIn: 1000),
      ],
    ),
    ProjectTemplate(
      id: 'cine_lower_third',
      title: 'Alt Band',
      subtitle: 'İsim + unvan (16:9)',
      category: 'Sinematik',
      width: 1920,
      height: 1080,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['lower-third'],
      icon: Icons.view_agenda,
      accent: const Color(0xFF5B8CFF),
      slots: [TemplateMediaSlot(label: 'Konuşmacı videosu', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('İsim Soyisim', start: 0, dur: 5000, size: 36, y: 0.82, anim: 'slideUp'),
        _t('Unvan / Rol', start: 300, dur: 4500, size: 22, y: 0.9, anim: 'fadeIn'),
      ],
    ),
    ProjectTemplate(
      id: 'yt_thumb_bar',
      title: 'Yatay Başlık',
      subtitle: 'YouTube / yatay banner',
      category: 'Sinematik',
      width: 1920,
      height: 1080,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['youtube'],
      icon: Icons.smart_display,
      accent: const Color(0xFFFF4D6A),
      slots: [TemplateMediaSlot(label: 'Ana görüntü', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('Video başlığı', start: 0, dur: 5000, size: 48, y: 0.82, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'cine_trailer',
      title: 'Mini Fragman',
      subtitle: 'Tease · title · date',
      category: 'Sinematik',
      width: 1920,
      height: 1080,
      durationMs: 9000,
      mediaSlots: 3,
      tags: ['trailer'],
      icon: Icons.local_movies,
      accent: const Color(0xFF94A3B8),
      isNew: true,
      difficulty: 'pro',
      slots: [
        TemplateMediaSlot(label: 'Tease 1', startMs: 0, durationMs: 2500),
        TemplateMediaSlot(label: 'Tease 2', startMs: 2500, durationMs: 2500),
        TemplateMediaSlot(label: 'Title card', startMs: 5000, durationMs: 4000),
      ],
      buildClips: () => [
        _t('Yakında…', start: 0, dur: 2500, size: 32, y: 0.5, anim: 'fadeIn', transition: 'fadeBlack', fadeIn: 600),
        _t('Bir sır', start: 2500, dur: 2500, size: 36, y: 0.5, anim: 'fadeIn', transition: 'fadeBlack'),
        _t('BAŞLIK', start: 5000, dur: 4000, size: 52, y: 0.45, anim: 'fadeIn', fadeIn: 800),
        _t('2026', start: 6000, dur: 3000, size: 24, y: 0.6, anim: 'fadeIn'),
      ],
    ),

    // ══════════ EĞİTİM ══════════
    ProjectTemplate(
      id: 'edu_tip',
      title: 'Hızlı İpucu',
      subtitle: 'Tek ipucu, net mesaj',
      category: 'Eğitim',
      width: 1080,
      height: 1920,
      durationMs: 4000,
      mediaSlots: 1,
      tags: ['tip', 'edu'],
      icon: Icons.lightbulb,
      accent: const Color(0xFFFFB020),
      isNew: true,
      slots: [TemplateMediaSlot(label: 'Demo videosu', startMs: 0, durationMs: 4000)],
      buildClips: () => [
        _t('İPUCU', start: 0, dur: 4000, size: 24, y: 0.2, anim: 'fadeIn'),
        _t('Buraya ipucunu yaz', start: 0, dur: 4000, size: 36, y: 0.45, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'edu_steps',
      title: '3 Adım',
      subtitle: 'Adım adım anlatım',
      category: 'Eğitim',
      width: 1080,
      height: 1920,
      durationMs: 9000,
      mediaSlots: 3,
      tags: ['howto'],
      icon: Icons.stairs,
      accent: const Color(0xFF22C55E),
      difficulty: 'medium',
      slots: [
        TemplateMediaSlot(label: 'Adım 1', startMs: 0, durationMs: 3000),
        TemplateMediaSlot(label: 'Adım 2', startMs: 3000, durationMs: 3000),
        TemplateMediaSlot(label: 'Adım 3', startMs: 6000, durationMs: 3000),
      ],
      buildClips: () => [
        _t('Adım 1', start: 0, dur: 3000, size: 40, y: 0.25, anim: 'fadeIn', transition: 'wipeLeft'),
        _t('Adım 2', start: 3000, dur: 3000, size: 40, y: 0.25, anim: 'slideLeft', transition: 'wipeLeft'),
        _t('Adım 3', start: 6000, dur: 3000, size: 40, y: 0.25, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'edu_myth',
      title: 'Doğru mu?',
      subtitle: 'Mit vs gerçek',
      category: 'Eğitim',
      width: 1080,
      height: 1920,
      durationMs: 6000,
      mediaSlots: 1,
      tags: ['myth'],
      icon: Icons.balance,
      accent: const Color(0xFF5B8CFF),
      slots: [TemplateMediaSlot(label: 'Açıklama videosu', startMs: 2500, durationMs: 3500)],
      buildClips: () => [
        _t('YANLIŞ?', start: 0, dur: 2500, size: 48, y: 0.4, anim: 'fadeIn', transition: 'crossfade'),
        _t('DOĞRU ✓', start: 2500, dur: 3500, size: 48, y: 0.4, anim: 'slideUp'),
      ],
    ),

    // ══════════ MÜZİK ══════════
    ProjectTemplate(
      id: 'music_lyric',
      title: 'Şarkı Sözü',
      subtitle: '4 satır lyric video',
      category: 'Müzik',
      width: 1080,
      height: 1920,
      durationMs: 8000,
      mediaSlots: 1,
      tags: ['lyric', 'music'],
      icon: Icons.lyrics,
      accent: const Color(0xFFE879F9),
      isNew: true,
      slots: [TemplateMediaSlot(label: 'Performans / görsel', startMs: 0, durationMs: 8000)],
      buildClips: () => [
        for (var i = 0; i < 4; i++)
          _t('Şarkı sözü ${i + 1}', start: i * 2000, dur: 2000, size: 32, y: 0.7, anim: 'typewriter', transition: i < 3 ? 'crossfade' : 'none'),
      ],
    ),
    ProjectTemplate(
      id: 'music_drop',
      title: 'Beat Drop',
      subtitle: 'Build-up + drop metni',
      category: 'Müzik',
      width: 1080,
      height: 1920,
      durationMs: 6000,
      mediaSlots: 1,
      tags: ['beat', 'drop'],
      icon: Icons.graphic_eq,
      accent: const Color(0xFFFF4D6A),
      isHot: true,
      slots: [TemplateMediaSlot(label: 'Klip + müzik', startMs: 0, durationMs: 6000)],
      buildClips: () => [
        _t('…', start: 0, dur: 3000, size: 48, y: 0.45, anim: 'fadeIn', transition: 'fadeBlack'),
        _t('DROP', start: 3000, dur: 3000, size: 72, y: 0.45, anim: 'slideUp'),
      ],
    ),
    ProjectTemplate(
      id: 'music_artist',
      title: 'Sanatçı Kartı',
      subtitle: 'İsim + şarkı adı',
      category: 'Müzik',
      width: 1080,
      height: 1920,
      durationMs: 5000,
      mediaSlots: 1,
      tags: ['artist'],
      icon: Icons.album,
      accent: const Color(0xFF22D3EE),
      slots: [TemplateMediaSlot(label: 'Kapak / performans', startMs: 0, durationMs: 5000)],
      buildClips: () => [
        _t('Sanatçı', start: 0, dur: 5000, size: 40, y: 0.7, anim: 'slideUp'),
        _t('Şarkı Adı', start: 600, dur: 4400, size: 28, y: 0.8, anim: 'fadeIn'),
      ],
    ),
  ];
}
