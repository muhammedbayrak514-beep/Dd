import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

enum ClipType { video, image, audio, text }

/// Track indices used by the editor.
class TrackIndex {
  static const int video = 0;
  static const int audio = 1;
  static const int text = 2;
  static const int sticker = 3;
  /// Picture-in-picture / free video overlay (not packed into main V).
  static const int overlay = 4;
}

/// Single timeline clip. All times in milliseconds.
///
/// Text-specific fields are optional; missing keys in JSON load as defaults
/// so Stage 1–5 project files remain readable.
class ClipModel extends Equatable {
  final String id;
  final ClipType type;

  /// Absolute path inside app documents (after copy). Empty for text clips.
  final String filePath;

  final String displayName;
  final int sourceDurationMs;
  final int trimStartMs;
  final int trimEndMs;
  final int timelineStartMs;
  final int trackIndex;
  final double volume;
  final double speed;
  final double rotationDegrees;
  final bool flipHorizontal;
  /// Play media backwards (export + badge).
  final bool reversed;
  /// Prevents move / trim / reorder when true.
  final bool locked;
  /// none | red | orange | green | blue | purple
  final String colorTag;
  final double scale;
  final double opacity;
  /// Edge fade in/out (ms) for video opacity + audio afade.
  final int fadeInMs;
  final int fadeOutMs;

  // ── Text (only meaningful when type == text) ──
  final String textContent;
  final double fontSize;
  /// ARGB int, e.g. 0xFFFFFFFF
  final int textColorArgb;
  /// 0=left, 1=center, 2=right
  final int textAlign;
  /// Normalized position 0–1 relative to preview frame
  final double posX;
  final double posY;
  /// Catalog style id (see TextStyleCatalog). Default plain_white.
  final String textStyleId;
  /// none | fadeIn | fadeOut | fadeInOut | slideUp | slideDown | slideLeft | typewriter
  final String textAnimId;

  // ── Filter / transition (Stage 7) ──
  /// Stored as enum name string in JSON.
  final String filterId;
  /// 0.0 – 1.0
  final double filterIntensity;
  /// Transition *to the next clip* on the same track (mainly video).
  final String transitionId;
  final int transitionDurationMs;

  const ClipModel({
    required this.id,
    required this.type,
    required this.filePath,
    required this.displayName,
    required this.sourceDurationMs,
    this.trimStartMs = 0,
    required this.trimEndMs,
    required this.timelineStartMs,
    this.trackIndex = 0,
    this.volume = 1.0,
    this.speed = 1.0,
    this.rotationDegrees = 0.0,
    this.flipHorizontal = false,
    this.reversed = false,
    this.locked = false,
    this.colorTag = 'none',
    this.scale = 1.0,
    this.opacity = 1.0,
    this.fadeInMs = 0,
    this.fadeOutMs = 0,
    this.textContent = '',
    this.fontSize = 32,
    this.textColorArgb = 0xFFFFFFFF,
    this.textAlign = 1,
    this.posX = 0.5,
    this.posY = 0.5,
    this.textStyleId = 'plain_white',
    this.textAnimId = 'none',
    this.filterId = 'none',
    this.filterIntensity = 1.0,
    this.transitionId = 'none',
    this.transitionDurationMs = 500,
  });

  int get durationMs {
    final trimmed = (trimEndMs - trimStartMs).clamp(0, sourceDurationMs > 0 ? sourceDurationMs : 1 << 30);
    if (speed <= 0) return trimmed;
    return (trimmed / speed).round();
  }

  int get timelineEndMs => timelineStartMs + durationMs;

  ClipModel copyWith({
    String? id,
    ClipType? type,
    String? filePath,
    String? displayName,
    int? sourceDurationMs,
    int? trimStartMs,
    int? trimEndMs,
    int? timelineStartMs,
    int? trackIndex,
    double? volume,
    double? speed,
    double? rotationDegrees,
    bool? flipHorizontal,
    bool? reversed,
    bool? locked,
    String? colorTag,
    double? scale,
    double? opacity,
    int? fadeInMs,
    int? fadeOutMs,
    String? textContent,
    double? fontSize,
    int? textColorArgb,
    int? textAlign,
    double? posX,
    double? posY,
    String? textStyleId,
    String? textAnimId,
    String? filterId,
    double? filterIntensity,
    String? transitionId,
    int? transitionDurationMs,
  }) {
    return ClipModel(
      id: id ?? this.id,
      type: type ?? this.type,
      filePath: filePath ?? this.filePath,
      displayName: displayName ?? this.displayName,
      sourceDurationMs: sourceDurationMs ?? this.sourceDurationMs,
      trimStartMs: trimStartMs ?? this.trimStartMs,
      trimEndMs: trimEndMs ?? this.trimEndMs,
      timelineStartMs: timelineStartMs ?? this.timelineStartMs,
      trackIndex: trackIndex ?? this.trackIndex,
      volume: volume ?? this.volume,
      speed: speed ?? this.speed,
      rotationDegrees: rotationDegrees ?? this.rotationDegrees,
      flipHorizontal: flipHorizontal ?? this.flipHorizontal,
      reversed: reversed ?? this.reversed,
      locked: locked ?? this.locked,
      colorTag: colorTag ?? this.colorTag,
      scale: scale ?? this.scale,
      opacity: opacity ?? this.opacity,
      fadeInMs: fadeInMs ?? this.fadeInMs,
      fadeOutMs: fadeOutMs ?? this.fadeOutMs,
      textContent: textContent ?? this.textContent,
      fontSize: fontSize ?? this.fontSize,
      textColorArgb: textColorArgb ?? this.textColorArgb,
      textAlign: textAlign ?? this.textAlign,
      posX: posX ?? this.posX,
      posY: posY ?? this.posY,
      textStyleId: textStyleId ?? this.textStyleId,
      textAnimId: textAnimId ?? this.textAnimId,
      filterId: filterId ?? this.filterId,
      filterIntensity: filterIntensity ?? this.filterIntensity,
      transitionId: transitionId ?? this.transitionId,
      transitionDurationMs: transitionDurationMs ?? this.transitionDurationMs,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'filePath': filePath,
        'displayName': displayName,
        'sourceDurationMs': sourceDurationMs,
        'trimStartMs': trimStartMs,
        'trimEndMs': trimEndMs,
        'timelineStartMs': timelineStartMs,
        'trackIndex': trackIndex,
        'volume': volume,
        'speed': speed,
        'rotationDegrees': rotationDegrees,
        'flipHorizontal': flipHorizontal,
        'reversed': reversed,
        'locked': locked,
        'colorTag': colorTag,
        'scale': scale,
        'opacity': opacity,
        'fadeInMs': fadeInMs,
        'fadeOutMs': fadeOutMs,
        'textContent': textContent,
        'fontSize': fontSize,
        'textColorArgb': textColorArgb,
        'textAlign': textAlign,
        'posX': posX,
        'posY': posY,
        'textStyleId': textStyleId,
        'textAnimId': textAnimId,
        'filterId': filterId,
        'filterIntensity': filterIntensity,
        'transitionId': transitionId,
        'transitionDurationMs': transitionDurationMs,
      };

  factory ClipModel.fromJson(Map<String, dynamic> json) {
    return ClipModel(
      id: json['id'] as String,
      type: ClipType.values.byName(json['type'] as String),
      filePath: json['filePath'] as String? ?? '',
      displayName: json['displayName'] as String,
      sourceDurationMs: json['sourceDurationMs'] as int,
      trimStartMs: json['trimStartMs'] as int? ?? 0,
      trimEndMs: json['trimEndMs'] as int,
      timelineStartMs: json['timelineStartMs'] as int,
      trackIndex: json['trackIndex'] as int? ?? 0,
      volume: (json['volume'] as num?)?.toDouble() ?? 1.0,
      speed: (json['speed'] as num?)?.toDouble() ?? 1.0,
      rotationDegrees: (json['rotationDegrees'] as num?)?.toDouble() ?? 0.0,
      flipHorizontal: json['flipHorizontal'] as bool? ?? false,
      reversed: json['reversed'] as bool? ?? false,
      locked: json['locked'] as bool? ?? false,
      colorTag: json['colorTag'] as String? ?? 'none',
      scale: (json['scale'] as num?)?.toDouble() ?? 1.0,
      opacity: (json['opacity'] as num?)?.toDouble() ?? 1.0,
      fadeInMs: json['fadeInMs'] as int? ?? 0,
      fadeOutMs: json['fadeOutMs'] as int? ?? 0,
      textContent: json['textContent'] as String? ?? '',
      fontSize: (json['fontSize'] as num?)?.toDouble() ?? 32,
      textColorArgb: json['textColorArgb'] as int? ?? 0xFFFFFFFF,
      textAlign: json['textAlign'] as int? ?? 1,
      posX: (json['posX'] as num?)?.toDouble() ?? 0.5,
      posY: (json['posY'] as num?)?.toDouble() ?? 0.5,
      textStyleId: json['textStyleId'] as String? ?? 'plain_white',
      textAnimId: json['textAnimId'] as String? ?? 'none',
      filterId: json['filterId'] as String? ?? 'none',
      filterIntensity: (json['filterIntensity'] as num?)?.toDouble() ?? 1.0,
      transitionId: json['transitionId'] as String? ?? 'none',
      transitionDurationMs: json['transitionDurationMs'] as int? ?? 500,
    );
  }

  factory ClipModel.fromImportedMedia({
    required String filePath,
    required String displayName,
    required ClipType type,
    required int sourceDurationMs,
    required int timelineStartMs,
    int trackIndex = 0,
  }) {
    return ClipModel(
      id: const Uuid().v4(),
      type: type,
      filePath: filePath,
      displayName: displayName,
      sourceDurationMs: sourceDurationMs,
      trimStartMs: 0,
      trimEndMs: sourceDurationMs,
      timelineStartMs: timelineStartMs,
      trackIndex: trackIndex,
    );
  }

  /// Create a text overlay clip (no media file).
  factory ClipModel.text({
    required String content,
    required int durationMs,
    required int timelineStartMs,
    double fontSize = 32,
    int textColorArgb = 0xFFFFFFFF,
    int textAlign = 1,
    double posX = 0.5,
    double posY = 0.85,
    String textStyleId = 'plain_white',
  }) {
    final d = durationMs < 100 ? 100 : durationMs;
    return ClipModel(
      id: const Uuid().v4(),
      type: ClipType.text,
      filePath: '',
      displayName: content.length > 24 ? '${content.substring(0, 24)}…' : content,
      sourceDurationMs: d,
      trimStartMs: 0,
      trimEndMs: d,
      timelineStartMs: timelineStartMs,
      trackIndex: TrackIndex.text,
      textContent: content,
      fontSize: fontSize,
      textColorArgb: textColorArgb,
      textAlign: textAlign,
      posX: posX,
      posY: posY,
      textStyleId: textStyleId,
    );
  }

  @override
  List<Object?> get props => [
        id,
        type,
        filePath,
        displayName,
        sourceDurationMs,
        trimStartMs,
        trimEndMs,
        timelineStartMs,
        trackIndex,
        volume,
        speed,
        rotationDegrees,
        flipHorizontal,
        reversed,
        locked,
        colorTag,
        scale,
        opacity,
        fadeInMs,
        fadeOutMs,
        textContent,
        fontSize,
        textColorArgb,
        textAlign,
        posX,
        posY,
        textStyleId,
        textAnimId,
        filterId,
        filterIntensity,
        transitionId,
        transitionDurationMs,
      ];
}
