/// CapCut-style preset text animations (preview + light export support).
class TextAnimDef {
  final String id;
  final String label;
  final String description;

  const TextAnimDef({
    required this.id,
    required this.label,
    required this.description,
  });
}

class TextAnimCatalog {
  static const String defaultId = 'none';

  static const all = <TextAnimDef>[
    TextAnimDef(id: 'none', label: 'Yok', description: 'Animasyon yok'),
    TextAnimDef(id: 'fadeIn', label: 'Fade In', description: 'Belirme'),
    TextAnimDef(id: 'fadeOut', label: 'Fade Out', description: 'Kaybolma'),
    TextAnimDef(id: 'fadeInOut', label: 'Fade In-Out', description: 'Giriş + çıkış'),
    TextAnimDef(id: 'slideUp', label: 'Yukarı kay', description: 'Alttan gelir'),
    TextAnimDef(id: 'slideDown', label: 'Aşağı kay', description: 'Üstten gelir'),
    TextAnimDef(id: 'slideLeft', label: 'Sola kay', description: 'Sağdan gelir'),
    TextAnimDef(id: 'typewriter', label: 'Daktilo', description: 'Harf harf yazar'),
  ];

  static TextAnimDef byId(String id) =>
      all.firstWhere((a) => a.id == id, orElse: () => all.first);
}
