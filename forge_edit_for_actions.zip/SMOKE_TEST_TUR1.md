# Tur 1 — Cihaz smoke checklist

## 1. Timeline thumbnail
- [ ] Foto klipte gerçek küçük resim görünüyor
- [ ] Video klipte ilk kare (veya trim başlangıcı) görünüyor (birkaç sn içinde)
- [ ] Ses / metin kliplerinde ikon görünüyor

## 2. Opacity
- [ ] Klip seç → Opaklık slider %50 → önizleme soluk
- [ ] Export MP4 → galeride de soluk (siyah üzerine)

## 3. wipeLeft
- [ ] İki video, ilk klipte geçiş = Sola sil
- [ ] Export → klipler arasında silme geçişi

## 4. Regresyon
- [ ] Play ile çok klipli oynatma
- [ ] crossfade / fadeBlack
- [ ] Alt bar: Medya / Ses / Metin / Efekt
- [ ] Export sonrası galeri (Movies/ForgeEdit)
