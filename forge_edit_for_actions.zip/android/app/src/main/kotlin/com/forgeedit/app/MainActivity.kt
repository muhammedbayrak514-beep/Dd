package com.forgeedit.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
