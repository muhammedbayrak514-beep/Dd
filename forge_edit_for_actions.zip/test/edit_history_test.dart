import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/edit_history.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/models/project_model.dart';

void main() {
  test('undo redo restores clips', () {
    final h = EditHistory();
    var p = ProjectModel.create(name: 't');
    final a = ClipModel.fromImportedMedia(
      filePath: '/a.mp4',
      displayName: 'a',
      type: ClipType.video,
      sourceDurationMs: 1000,
      timelineStartMs: 0,
    );
    h.pushBeforeChange(p);
    p = p.addClip(a);
    expect(h.canUndo, true);

    final prev = h.undo(p)!;
    expect(prev.clips, isEmpty);
    final next = h.redo(prev)!;
    expect(next.clips.length, 1);
  });

  test('new push clears redo', () {
    final h = EditHistory();
    var p = ProjectModel.create();
    h.pushBeforeChange(p);
    p = p.copyWith(name: 'b');
    h.undo(p);
    expect(h.canRedo, true);
    h.pushBeforeChange(p);
    expect(h.canRedo, false);
  });

  test('coalesce single step', () {
    final h = EditHistory();
    var p = ProjectModel.create(name: 'base');
    h.beginCoalesce(p, 'trim_x');
    p = p.copyWith(name: 'mid');
    h.pushBeforeChange(p, coalesceKey: 'trim_x');
    expect(h.undoCount, 1);
    h.endCoalesce();
    expect(h.undo(p)!.name, 'base');
  });

  test('max depth 40', () {
    final h = EditHistory();
    var p = ProjectModel.create();
    for (var i = 0; i < 45; i++) {
      h.pushBeforeChange(p);
      p = p.copyWith(name: 'n$i');
    }
    expect(h.undoCount, EditHistory.maxDepth);
  });

  test('snapshots independent', () {
    final h = EditHistory();
    var p = ProjectModel.create(name: 'a');
    h.pushBeforeChange(p);
    p = p.copyWith(name: 'b');
    final snap = h.undo(p)!;
    p = p.copyWith(name: 'c');
    expect(snap.name, 'a');
  });
}
