import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/models/clip_model.dart';
import 'package:forge_edit/domain/timeline_playback.dart';

ClipModel v({
  required String id,
  required int start,
  required int duration,
  ClipType type = ClipType.video,
}) {
  return ClipModel(
    id: id,
    type: type,
    filePath: '/tmp/$id.mp4',
    displayName: id,
    sourceDurationMs: duration,
    trimStartMs: 0,
    trimEndMs: duration,
    timelineStartMs: start,
    trackIndex: 0,
  );
}

void main() {
  final clips = [
    v(id: 'a', start: 0, duration: 3000),
    v(id: 'b', start: 3000, duration: 2000, type: ClipType.image),
    v(id: 'c', start: 5000, duration: 4000),
  ];

  test('visualClipAt finds covering clip', () {
    expect(TimelinePlayback.visualClipAt(clips, 0)?.id, 'a');
    expect(TimelinePlayback.visualClipAt(clips, 2999)?.id, 'a');
    expect(TimelinePlayback.visualClipAt(clips, 3000)?.id, 'b');
    expect(TimelinePlayback.visualClipAt(clips, 4999)?.id, 'b');
    expect(TimelinePlayback.visualClipAt(clips, 5000)?.id, 'c');
    expect(TimelinePlayback.visualClipAt(clips, 9000), isNull);
  });

  test('nextAfter walks sequence', () {
    expect(TimelinePlayback.nextAfter(clips, 'a')?.id, 'b');
    expect(TimelinePlayback.nextAfter(clips, 'b')?.id, 'c');
    expect(TimelinePlayback.nextAfter(clips, 'c'), isNull);
    expect(TimelinePlayback.nextAfter(clips, 'missing'), isNull);
  });

  test('nextVisualAtOrAfter skips past gaps', () {
    expect(TimelinePlayback.nextVisualAtOrAfter(clips, 0)?.id, 'a');
    expect(TimelinePlayback.nextVisualAtOrAfter(clips, 3500)?.id, 'b');
    expect(TimelinePlayback.nextVisualAtOrAfter(clips, 10000), isNull);
  });

  test('projectToLocalMs respects trim', () {
    final clip = ClipModel(
      id: 't',
      type: ClipType.video,
      filePath: '/t.mp4',
      displayName: 't',
      sourceDurationMs: 10000,
      trimStartMs: 1000,
      trimEndMs: 5000,
      timelineStartMs: 2000,
    );
    // durationMs = 4000
    expect(TimelinePlayback.projectToLocalMs(clip, 2000), 1000);
    expect(TimelinePlayback.projectToLocalMs(clip, 3000), 2000);
    expect(TimelinePlayback.projectToLocalMs(clip, 6000), 5000);
  });

  test('isAtClipEnd', () {
    final clip = v(id: 'x', start: 0, duration: 1000);
    expect(TimelinePlayback.isAtClipEnd(clip, 950), isTrue);
    expect(TimelinePlayback.isAtClipEnd(clip, 500), isFalse);
  });

  test('ignores audio/text for visual queries', () {
    final mixed = [
      ...clips,
      ClipModel(
        id: 'aud',
        type: ClipType.audio,
        filePath: '/a.mp3',
        displayName: 'aud',
        sourceDurationMs: 10000,
        trimEndMs: 10000,
        timelineStartMs: 0,
        trackIndex: 1,
      ),
    ];
    expect(TimelinePlayback.visualClipsSorted(mixed).length, 3);
    expect(TimelinePlayback.visualClipAt(mixed, 100)?.id, 'a');
  });
}
