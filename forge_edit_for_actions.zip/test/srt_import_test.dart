import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/data/services/srt_import_service.dart';

void main() {
  test('parse basic srt cues', () {
    const raw = '1\n'
        '00:00:01,000 --> 00:00:03,500\n'
        'Merhaba dunya\n'
        '\n'
        '2\n'
        '00:00:04,000 --> 00:00:06,000\n'
        'Ikinci satir\n';
    final cues = SrtImportService.parse(raw);
    expect(cues.length, 2);
    expect(cues.first.startMs, 1000);
    expect(cues.first.endMs, 3500);
    expect(cues.first.text, 'Merhaba dunya');
    final clips = SrtImportService.cuesToTextClips(cues);
    expect(clips.length, 2);
    expect(clips.first.timelineStartMs, 1000);
  });
}
