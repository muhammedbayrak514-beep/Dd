
import 'package:flutter_test/flutter_test.dart';
import 'package:forge_edit/domain/export/export_text_style.dart';
import 'package:forge_edit/domain/models/clip_model.dart';

void main() {
  group('ExportTextStyle', () {
    test('uppercase + shadow from catalog style', () {
      final clip = ClipModel(
        id: 't1',
        type: ClipType.text,
        filePath: '',
        displayName: 'text',
        sourceDurationMs: 3000,
        trimEndMs: 3000,
        timelineStartMs: 500,
        textContent: 'hello',
        fontSize: 40,
        textColorArgb: 0xFFFFFFFF,
        textStyleId: 'minimal_caps', // uppercase
        posX: 0.5,
        posY: 0.5,
      );
      final s = ExportTextStyle.fromClip(clip, frameWidth: 1280, frameHeight: 720);
      expect(s.text, 'HELLO');
      final frag = s.toDrawtext(fontFile: '/tmp/f.ttf');
      expect(frag.contains("text='HELLO'"), true);
      expect(frag.contains('fontsize=40'), true);
      expect(frag.contains('fontfile='), true);
      expect(frag.contains("enable='between(t\\,0.500\\,3.500)'"), true);
    });

    test('shadow fields when style has shadow', () {
      final clip = ClipModel(
        id: 't2',
        type: ClipType.text,
        filePath: '',
        displayName: 'text',
        sourceDurationMs: 1000,
        trimEndMs: 1000,
        timelineStartMs: 0,
        textContent: 'Hi',
        textStyleId: 'minimal_soft_shadow',
      );
      final s = ExportTextStyle.fromClip(clip, frameWidth: 1920, frameHeight: 1080);
      final frag = s.toDrawtext();
      expect(frag.contains('shadowx='), true);
      expect(frag.contains('shadowcolor='), true);
    });

    test('escapes special chars', () {
      final clip = ClipModel(
        id: 't3',
        type: ClipType.text,
        filePath: '',
        displayName: 'text',
        sourceDurationMs: 1000,
        trimEndMs: 1000,
        timelineStartMs: 0,
        textContent: "100% : 'quote'",
        textStyleId: 'plain_white',
      );
      final s = ExportTextStyle.fromClip(clip, frameWidth: 100, frameHeight: 100);
      expect(s.text.contains(r'\%'), true);
      expect(s.text.contains(r'\:'), true);
    });
  });

  group('ExportAudioMix', () {
    test('single clip builds oa + a0 + amix', () {
      final a = ClipModel(
        id: 'a1',
        type: ClipType.audio,
        filePath: '/tmp/a.mp3',
        displayName: 'a',
        sourceDurationMs: 5000,
        trimEndMs: 5000,
        timelineStartMs: 1000,
        volume: 0.8,
      );
      final fc = ExportAudioMix.build(clips: [a], videoDurSec: 10);
      expect(fc.contains('[0:a]'), true);
      expect(fc.contains('[1:a]'), true);
      expect(fc.contains('adelay=1000|1000'), true);
      expect(fc.contains('volume=0.80'), true);
      expect(fc.contains('amix=inputs=2'), true);
      expect(fc.contains('[aout]'), true);
    });

    test('two clips amix inputs=3', () {
      ClipModel audio(String id, int start) => ClipModel(
            id: id,
            type: ClipType.audio,
            filePath: '/tmp/$id.mp3',
            displayName: id,
            sourceDurationMs: 2000,
            trimEndMs: 2000,
            timelineStartMs: start,
          );
      final fc = ExportAudioMix.build(
        clips: [audio('x', 0), audio('y', 500)],
        videoDurSec: 8,
      );
      expect(fc.contains('[1:a]'), true);
      expect(fc.contains('[2:a]'), true);
      expect(fc.contains('amix=inputs=3'), true);
    });

    test('bg only single becomes anull', () {
      final a = ClipModel(
        id: 'a1',
        type: ClipType.audio,
        filePath: '/tmp/a.mp3',
        displayName: 'a',
        sourceDurationMs: 1000,
        trimEndMs: 1000,
        timelineStartMs: 0,
      );
      final fc = ExportAudioMix.buildBgOnly(clips: [a], videoDurSec: 5);
      expect(fc.contains('[0:a]'), false);
      expect(fc.contains('[aout]'), true);
    });
  });
}
