# ForgeEdit — Tablete APK Kurulumu

Bu ortamda (sunucu) Flutter SDK ile APK **derlenemedi**. Aşağıdaki adımları **kendi bilgisayarında** çalıştır.

## Gereksinimler

- Flutter 3.24+ (`flutter doctor` temiz olsun)
- Android SDK (API 24–35)
- USB hata ayıklama **veya** APK dosyasını tablete kopyalama

## 1. Derle

```bash
cd forge_edit
chmod +x build_apk.sh
./build_apk.sh
```

veya:

```bash
flutter pub get
flutter build apk --release
```

Çıktı:

`build/app/outputs/flutter-apk/app-release.apk`

## 2. Tablete kur

**ADB ile:**

```bash
adb devices
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

**Manuel:** APK’yı tablete kopyala → Dosya yöneticisinde aç →  
Ayarlar → Güvenlik → “Bilinmeyen kaynaklar”a izin ver → Kur.

## 3. İlk açılış

- Uygulama adı: **ForgeEdit**
- Paket: `com.forgeedit.app`
- Yatay (landscape) kullanımı önerilir
- Galeri / medya izni isteyecek — ver

## Sorun giderme

| Sorun | Çözüm |
|--------|--------|
| `flutter.sdk not set` | Proje klasöründe `flutter pub get` çalıştır |
| minSdk / ffmpeg hatası | `minSdk = 24` (zaten ayarlı) |
| İkon yok / build fail | `android/app/src/main/res/mipmap-*/ic_launcher.png` |
| Kurulum engellendi | Bilinmeyen kaynaklar + Play Protect geçici kapat |
| Siyah ekran | `adb logcat \| grep flutter` |

## Not

Release APK şu an **debug keystore** ile imzalıdır (test kurulumu için yeterli). Mağaza yayını için kendi keystore’unu kullan.
