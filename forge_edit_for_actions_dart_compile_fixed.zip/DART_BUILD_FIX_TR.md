# Forge Edit Dart derleme hatası düzeltmesi

GitHub Actions derleme günlüğündeki iki Dart hatası için yapılan düzeltmeler:

1. `preview_provider.dart`: `ClipType` üzerinde tanımlanmamış `isVideo` getter'ı yerine `under.type != ClipType.video` kontrolü kullanıldı. Bu blok yalnızca video denetleyicisine seek uygular.
2. `effects_sheet.dart`: ` _transitionIcon(String name)` metodu eklendi. `EffectCatalog.transitions` içindeki geçiş isimleri, Material ikonlarına eşlenir; bilinmeyen isimler için güvenli varsayılan ikon kullanılır.

Bu paketle gerçek Flutter/Android release derlemesi bu çalışma ortamında çalıştırılmadı. GitHub Actions üzerinde sonraki derlemede başka hatalar ortaya çıkabilir.
